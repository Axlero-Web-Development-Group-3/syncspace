import { useState, useEffect, useRef, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import { useSocket } from "../context/SocketContext";
import { useUnread } from "../context/UnreadContext";
import axios from "axios";
import {
  Hash,
  Send,
  Smile,
  Paperclip,
  Reply,
  Edit2,
  Trash2,
  Download,
  File,
  X,
  Heart,
  ThumbsUp,
  Mic,
  BarChart3,
  Pin,
  Loader2,
} from "lucide-react";
import { toast } from "react-hot-toast";

const safeToast = {
  success: (message, options) => {
    if (message && message !== "undefined") {
      return toast.success(message, options);
    } else {
      console.warn("Attempted to show undefined success toast:", message);
      return toast.success("Action completed successfully", options);
    }
  },
  error: (message, options) => {
    if (message && message !== "undefined") {
      return toast.error(message, options);
    } else {
      console.warn("Attempted to show undefined error toast:", message);
      return toast.error("An error occurred", options);
    }
  },
  loading: (message, options) => {
    if (message && message !== "undefined") {
      return toast.loading(message, options);
    } else {
      console.warn("Attempted to show undefined loading toast:", message);
      return toast.loading("Loading...", options);
    }
  },
  dismiss: toast.dismiss,
};
import EmojiPicker from "./EmojiPicker";
import MessageReactions from "./MessageReactions";
import PollDisplay from "./PollDisplay";
import TypingIndicator from "./TypingIndicator";
import MentionsList from "./MentionsList";
import FileUpload from "./FileUpload";
import VoiceRecorder from "./VoiceRecorder";
import QuickPoll from "./QuickPoll";

const TeamChat = ({ channelId, channelName }) => {
  const { user } = useAuth();
  const { socket, isConnected } = useSocket();
  const { markChannelAsRead } = useUnread();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [editingMessage, setEditingMessage] = useState(null);
  const [typingUsers, setTypingUsers] = useState([]);
  const [showMentions, setShowMentions] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [mentionPosition, setMentionPosition] = useState(0);
  const [selectedMentionIndex, setSelectedMentionIndex] = useState(0);
  const [channelMembers, setChannelMembers] = useState([]);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [polls, setPolls] = useState([]);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const [showPollModal, setShowPollModal] = useState(false);
  const [pinningMessageId, setPinningMessageId] = useState(null);

  const [dragOver, setDragOver] = useState(false);

  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const emojiPickerRef = useRef(null);
  const mentionsRef = useRef(null);
  const messageRefs = useRef({});

  // Optimized scroll to bottom for WhatsApp-like experience
  const scrollToBottom = useCallback((instant = false) => {
    if (messagesEndRef.current) {
      if (instant) {
        // Instant scroll for real-time messages
        messagesEndRef.current.scrollIntoView({ behavior: "auto" });
      } else {
        // Smooth scroll for user actions
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, []);

  // Scroll to a specific message
  const scrollToMessage = useCallback((messageId) => {
    const messageElement = messageRefs.current[messageId];
    if (messageElement) {
      messageElement.scrollIntoView({ behavior: "smooth", block: "center" });
      // Highlight the message briefly
      messageElement.classList.add("highlight-message");
      setTimeout(() => {
        messageElement.classList.remove("highlight-message");
      }, 2000);
    }
  }, []);

  // Hide FeatureHub when TeamChat is active
  useEffect(() => {
    // Find and hide the FeatureHub button
    const featureHubButton = document.querySelector('[title="Open features"], [title="Close features"]');
    if (featureHubButton) {
      const parentDiv = featureHubButton.closest('div');
      if (parentDiv) {
        parentDiv.style.display = 'none';
      }
    }

    // Show it again when component unmounts
    return () => {
      const featureHubButton = document.querySelector('[title="Open features"], [title="Close features"]');
      if (featureHubButton) {
        const parentDiv = featureHubButton.closest('div');
        if (parentDiv) {
          parentDiv.style.display = '';
        }
      }
    };
  }, []);

  // Fetch messages
  const fetchMessages = useCallback(async () => {
    if (!channelId || !user?.org_id) return;

    try {
      setLoading(true);
      const response = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/channels/${channelId}/messages`,
        { withCredentials: true }
      );
      setMessages(response.data.messages || []);
    } catch (error) {
      console.error("Error fetching messages:", error);
      toast.error("Failed to load messages");
    } finally {
      setLoading(false);
    }
  }, [channelId, user?.org_id]);

  // Fetch channel members for mentions
  const fetchChannelMembers = useCallback(async () => {
    if (!channelId || !user?.org_id) return;

    try {
      const response = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/channels/${channelId}/members`,
        { withCredentials: true }
      );
      const members = response.data.members || [];
      setChannelMembers(members);
    } catch (error) {
      console.error("Error fetching channel members:", error);
      toast.error("Failed to load channel members");
    }
  }, [channelId, user?.org_id]);

  // Fetch polls for channel
  const fetchPolls = useCallback(async () => {
    if (!channelId) return;

    try {
      const response = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/polls/channel/${channelId}`,
        { withCredentials: true }
      );
      setPolls(response.data.polls || []);
    } catch (error) {
      console.error("Error fetching polls:", error);
      // Silently fail if polls endpoint doesn't exist yet
    }
  }, [channelId]);

  // Socket event handlers
  useEffect(() => {
    if (!socket || !isConnected || !channelId) {
      return;
    }

    // Join channel room
    socket.emit("join_channel", channelId);

    // Listen for new messages - Optimized for instant WhatsApp-like updates
    const handleNewMessage = (message) => {
      setMessages((prev) => [...prev, { ...message, isNew: true }]);

      // Immediate instant scroll for real-time messages
      requestAnimationFrame(() => {
        scrollToBottom(true); // Instant scroll for new messages
      });

      // Remove the isNew flag after shorter animation for faster feel
      setTimeout(() => {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === message.message_id
              ? { ...msg, isNew: false }
              : msg
          )
        );
      }, 500); // Reduced from 1000ms to 500ms
    };

    // Listen for message updates
    const handleMessageUpdate = (updatedMessage) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === updatedMessage.message_id ? updatedMessage : msg
        )
      );
    };

    // Listen for message deletions
    const handleMessageDelete = (messageId) => {
      console.log('Socket event: message_deleted', messageId);
      setMessages((prev) => {
        const updated = prev.map((msg) =>
          msg.message_id === messageId && !msg.isDeleted
            ? {
                ...msg,
                isDeleted: true,
                originalContent: msg.originalContent || msg.content,
                content: "This message was deleted",
              }
            : msg
        );
        console.log('Messages after socket delete:', updated.find(m => m.message_id === messageId));
        return updated;
      });
    };

    // Listen for typing indicators
    const handleUserTyping = (data) => {
      if (data.userId !== user.user_id) {
        setTypingUsers((prev) => {
          const existing = prev.find((u) => u.userId === data.userId);
          if (!existing) {
            const newUsers = [
              ...prev,
              {
                userId: data.userId,
                userName: data.userName,
                timestamp: Date.now(),
              },
            ];
            return newUsers;
          } else {
            // Update timestamp for existing user
            const updated = prev.map((u) =>
              u.userId === data.userId ? { ...u, timestamp: Date.now() } : u
            );
            return updated;
          }
        });
      }
    };

    const handleUserStoppedTyping = (data) => {
      setTypingUsers((prev) => {
        const filtered = prev.filter((u) => u.userId !== data.userId);
        return filtered;
      });
    };

    // Listen for reactions
    const handleReactionUpdate = (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, reactions: data.reactions || [] }
            : msg
        )
      );
    };

    socket.on("new_message", handleNewMessage);
    socket.on("message_updated", handleMessageUpdate);
    socket.on("message_deleted", handleMessageDelete);
    socket.on("user_typing", handleUserTyping);
    socket.on("user_stopped_typing", handleUserStoppedTyping);
    socket.on("reaction_updated", handleReactionUpdate);

    // Listen for pin/unpin events
    socket.on("message_pinned", (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, is_pinned: true }
            : msg
        )
      );
    });

    socket.on("message_unpinned", (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, is_pinned: false }
            : msg
        )
      );
    });

    // Listen for poll events
    socket.on("new_poll", (poll) => {
      setPolls((prev) => [poll, ...prev]);
      // Don't show toast here - creator already sees it from QuickPoll component
    });

    socket.on("poll_updated", (updatedPoll) => {
      setPolls((prev) =>
        prev.map((p) => (p.poll_id === updatedPoll.poll_id ? updatedPoll : p))
      );
    });

    socket.on("poll_deleted", (data) => {
      setPolls((prev) => prev.filter((p) => p.poll_id !== data.pollId));
    });

    // Listen for mention notifications
    socket.on("user_mentioned", (data) => {
      if (data.mentionedUserId === user.user_id) {
        const mentionedBy = data.mentionedBy || data.userName || "Someone";
        const channelName = data.channelName || "a channel";

        // Only show toast if we're not currently in this channel to avoid duplicate notifications
        if (data.channelId !== channelId) {
          toast(`${mentionedBy} mentioned you in #${channelName}`, {
            icon: "👋",
          });
        }
      }
    });

    return () => {
      socket.off("new_message", handleNewMessage);
      socket.off("message_updated", handleMessageUpdate);
      socket.off("message_deleted", handleMessageDelete);
      socket.off("user_typing", handleUserTyping);
      socket.off("user_stopped_typing", handleUserStoppedTyping);
      socket.off("reaction_updated", handleReactionUpdate);
      socket.off("message_pinned");
      socket.off("message_unpinned");
      socket.off("new_poll");
      socket.off("poll_updated");
      socket.off("poll_deleted");
      socket.off("user_mentioned");
      socket.emit("leave_channel", channelId);
    };
  }, [socket, isConnected, channelId, user?.user_id, scrollToBottom]);

  // Initialize data
  useEffect(() => {
    fetchMessages();
    fetchChannelMembers();
    fetchPolls();

    // Mark channel as read when user opens it
    if (channelId) {
      markChannelAsRead(channelId);
    }
  }, [fetchMessages, fetchChannelMembers, fetchPolls, channelId, markChannelAsRead]);

  // Ensure members are fetched when channel changes
  useEffect(() => {
    if (channelId && user?.org_id) {
      fetchChannelMembers();
    }
  }, [channelId, user?.org_id]);

  // Handle click outside for emoji picker
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        emojiPickerRef.current &&
        !emojiPickerRef.current.contains(event.target)
      ) {
        setShowEmojiPicker(false);
      }
    };

    if (showEmojiPicker) {
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [showEmojiPicker]);

  // Handle click outside for mentions
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        mentionsRef.current &&
        !mentionsRef.current.contains(event.target) &&
        textareaRef.current &&
        !textareaRef.current.contains(event.target)
      ) {
        setShowMentions(false);
        setMentionQuery("");
      }
    };

    if (showMentions) {
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [showMentions]);

  // Auto-scroll on new messages - Optimized to prevent unnecessary scrolling
  useEffect(() => {
    // Only scroll if there are messages and the last message is new or from current user
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      const shouldScroll =
        lastMessage.isNew || lastMessage.user_id === user.user_id;

      if (shouldScroll) {
        // Use requestAnimationFrame for smoother scrolling
        requestAnimationFrame(() => {
          scrollToBottom(true); // Instant scroll for better performance
        });
      }
    }
  }, [messages.length, user.user_id, scrollToBottom]); // Only depend on messages length, not entire array

  // Update timestamps every 30 seconds for better accuracy - optimized to avoid unnecessary re-renders
  useEffect(() => {
    const interval = setInterval(() => {
      // Only update if there are messages and user is actively viewing
      if (messages.length > 0 && document.visibilityState === "visible") {
        // Force re-render to update timestamps only when needed
        setMessages((prev) => [...prev]);
      }
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [messages.length]); // Only depend on messages length, not the entire messages array

  // Listen for scroll to message events
  useEffect(() => {
    const handleScrollToMessage = (event) => {
      const { messageId } = event.detail;
      scrollToMessage(messageId);
    };

    window.addEventListener('scrollToMessage', handleScrollToMessage);
    return () => {
      window.removeEventListener('scrollToMessage', handleScrollToMessage);
    };
  }, [scrollToMessage]);

  // Cleanup typing timeout on unmount or channel change
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      // Stop typing when component unmounts or channel changes
      if (socket && isConnected && channelId) {
        socket.emit("typing_stop", { channelId });
      }
    };
  }, [channelId, socket, isConnected]);

  // Cleanup stale typing users (remove users who have been typing for more than 5 seconds)
  useEffect(() => {
    const cleanupInterval = setInterval(() => {
      const now = Date.now();
      setTypingUsers((prev) => {
        const filtered = prev.filter((user) => {
          const timeDiff = now - (user.timestamp || 0);
          return timeDiff < 5000; // Remove if older than 5 seconds
        });
        return filtered;
      });
    }, 1000);

    return () => clearInterval(cleanupInterval);
  }, []);

  // Handle typing indicators
  const handleTypingStart = useCallback(() => {
    if (socket && isConnected && channelId) {
      socket.emit("typing_start", {
        channelId,
        userName: user.name,
      });
    }
  }, [socket, isConnected, channelId, user?.name]);

  const handleTypingStop = useCallback(() => {
    if (socket && isConnected && channelId) {
      socket.emit("typing_stop", { channelId });
    }
  }, [socket, isConnected, channelId]);

  // Handle message input changes
  const handleInputChange = (e) => {
    const value = e.target.value;
    setNewMessage(value);

    // Handle mentions - stop at first space
    const cursorPosition = e.target.selectionStart;
    const textBeforeCursor = value.substring(0, cursorPosition);
    const mentionMatch = textBeforeCursor.match(/@([a-zA-Z0-9_]*)$/);

    if (mentionMatch) {
      const query = mentionMatch[1];
      setShowMentions(true);
      setMentionQuery(query);
      setMentionPosition(cursorPosition);
      setSelectedMentionIndex(0); // Reset selection
    } else {
      setShowMentions(false);
      setMentionQuery("");
      setSelectedMentionIndex(0);
    }

    // Handle typing indicators - only if user is actually typing
    if (value.trim() !== "") {
      handleTypingStart();

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      // Set new timeout for stopping typing indicator - WhatsApp-like timing
      typingTimeoutRef.current = setTimeout(() => {
        handleTypingStop();
      }, 1500); // Optimized to 1.5 seconds for faster response
    } else {
      // If input is empty, stop typing immediately
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      handleTypingStop();
    }

    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height =
        Math.min(textareaRef.current.scrollHeight, 120) + "px";
    }
  };

  // Send message - Optimized for instant WhatsApp-like experience
  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() && !replyingTo) return;

    const messageContent = newMessage.trim();
    const currentReplyingTo = replyingTo;

    // Clear input immediately for instant feel
    setNewMessage("");
    setReplyingTo(null);
    setShowMentions(false);
    handleTypingStop();

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    setSending(true);
    try {
      const messageData = {
        content: messageContent,
        channel_id: channelId,
        reply_to: currentReplyingTo?.message_id || null,
        mentions: extractMentions(messageContent),
      };

      if (editingMessage) {
        // Update existing message
        await axios.put(
          `${import.meta.env.VITE_BASE_URL}/api/messages/${
            editingMessage.message_id
          }`,
          { content: messageContent },
          { withCredentials: true }
        );
        setEditingMessage(null);
      } else {
        // Send new message - socket will handle real-time updates
        await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/messages`,
          messageData,
          { withCredentials: true }
        );
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  // Extract mentions from message
  const extractMentions = (text) => {
    const mentions = [];

    // Find all @mentions in the text
    channelMembers.forEach((member) => {
      const mentionPattern = new RegExp(
        `@${member.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s|$)`,
        "gi"
      );
      if (mentionPattern.test(text)) {
        mentions.push(member.user_id);
      }
    });

    return [...new Set(mentions)]; // Remove duplicates
  };

  // Handle mention selection
  const handleMentionSelect = (member) => {
    const beforeMention = newMessage.substring(
      0,
      mentionPosition - mentionQuery.length - 1
    );
    const afterMention = newMessage.substring(mentionPosition);
    const newText = `${beforeMention}@${member.name} ${afterMention}`;

    setNewMessage(newText);
    setShowMentions(false);
    setMentionQuery("");

    // Set cursor position after the mention
    setTimeout(() => {
      if (textareaRef.current) {
        const newCursorPosition = beforeMention.length + member.name.length + 2; // +2 for @ and space
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(
          newCursorPosition,
          newCursorPosition
        );
      }
    }, 0);
  };

  // Handle emoji selection
  const handleEmojiSelect = (emoji) => {
    setNewMessage((prev) => prev + emoji);
    setShowEmojiPicker(false);
    textareaRef.current?.focus();
  };

  // Handle voice message
  const handleVoiceMessage = async (audioFile) => {
    const uploadToast = safeToast.loading("Uploading voice message...");
    
    try {
      const formData = new FormData();
      formData.append("file", audioFile);
      formData.append("channel_id", channelId);
      formData.append("is_voice", "true");

      await axios.post(
        `${import.meta.env.VITE_BASE_URL}/api/messages/file`,
        formData,
        {
          withCredentials: true,
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      safeToast.success("Voice message sent!", { id: uploadToast });
    } catch (error) {
      console.error("Error sending voice message:", error);
      safeToast.error("Failed to send voice message", { id: uploadToast });
    }
  };

  // Handle file upload
  const handleFileUpload = async (files) => {
    const uploadPromises = files.map(async (file) => {
      // Ensure file has a name
      const fileName = file.name || "Unknown file";

      // Show upload progress toast
      const uploadToast = safeToast.loading(`Uploading ${fileName}...`);

      try {

        const formData = new FormData();
        formData.append("file", file);
        formData.append("channel_id", channelId);

        const response = await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/messages/file`,
          formData,
          {
            withCredentials: true,
            headers: { "Content-Type": "multipart/form-data" },
            timeout: 60000, // 60 second timeout for large files
            onUploadProgress: (progressEvent) => {
              if (progressEvent.total && progressEvent.loaded) {
                const percentCompleted = Math.round(
                  (progressEvent.loaded * 100) / progressEvent.total
                );
                const uploadedMB = (progressEvent.loaded / 1024 / 1024).toFixed(
                  1
                );
                const totalMB = (progressEvent.total / 1024 / 1024).toFixed(1);

                safeToast.loading(
                  `Uploading ${fileName}... ${percentCompleted}% (${uploadedMB}/${totalMB} MB)`,
                  {
                    id: uploadToast,
                  }
                );
              }
            },
          }
        );

        safeToast.success(`${fileName} uploaded successfully!`, {
          id: uploadToast,
        });

        return response.data;
      } catch (error) {
        console.error("Error uploading file:", error);

        // Dismiss the loading toast
        toast.dismiss(uploadToast);

        // Show error message with proper fallback
        let errorMessage = "Unknown error occurred";
        if (error.response?.data?.message) {
          errorMessage = error.response.data.message;
        } else if (error.message) {
          errorMessage = error.message;
        } else if (typeof error === "string") {
          errorMessage = error;
        }

        safeToast.error(`Failed to upload ${fileName}: ${errorMessage}`);
        throw error;
      }
    });

    try {
      await Promise.all(uploadPromises);
      // Close the file upload modal after successful upload
      setShowFileUpload(false);
    } catch (error) {
      console.error("Some files failed to upload:", error);
      // Keep modal open if there were errors so user can retry
    }
  };

  // Handle message reactions
  const handleReaction = async (messageId, emoji) => {
    // Optimistic update - update UI immediately
    const currentMessage = messages.find((msg) => msg.message_id === messageId);
    if (!currentMessage) return;

    const existingReactions = currentMessage.reactions || [];
    const existingReaction = existingReactions.find(
      (r) => r.emoji === emoji && r.user_id === user.user_id
    );

    let optimisticReactions;
    if (existingReaction) {
      // Remove reaction optimistically
      optimisticReactions = existingReactions.filter(
        (r) => !(r.emoji === emoji && r.user_id === user.user_id)
      );
    } else {
      // Add reaction optimistically
      optimisticReactions = [
        ...existingReactions,
        {
          emoji,
          user_id: user.user_id,
          user_name: user.name,
          created_at: new Date().toISOString(),
        },
      ];
    }

    // Update UI immediately
    setMessages((prev) =>
      prev.map((msg) =>
        msg.message_id === messageId
          ? { ...msg, reactions: optimisticReactions }
          : msg
      )
    );

    try {
      // Send to server
      const response = await axios.post(
        `${import.meta.env.VITE_BASE_URL}/api/messages/${messageId}/reactions`,
        { emoji },
        { withCredentials: true }
      );

      // Update with server response (in case of conflicts)
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId
            ? { ...msg, reactions: response.data.reactions || [] }
            : msg
        )
      );
    } catch (error) {
      console.error("Error adding reaction:", error);
      toast.error("Failed to add reaction");

      // Revert optimistic update on error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId
            ? { ...msg, reactions: existingReactions }
            : msg
        )
      );
    }
  };

  // Handle message pinning
  const handlePinMessage = async (messageId) => {
    if (pinningMessageId) return; // Prevent multiple simultaneous pin operations
    
    try {
      setPinningMessageId(messageId);
      const message = messages.find(m => m.message_id === messageId);
      const isPinned = message?.is_pinned;

      if (isPinned) {
        // Unpin message
        await axios.delete(
          `${import.meta.env.VITE_BASE_URL}/api/messages/${messageId}/pin`,
          { withCredentials: true }
        );
        
        // Update local state
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === messageId
              ? { ...msg, is_pinned: false }
              : msg
          )
        );
        
        toast.success("Message unpinned");
      } else {
        // Pin message
        await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/messages/${messageId}/pin`,
          { channel_id: channelId },
          { withCredentials: true }
        );
        
        // Update local state
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === messageId
              ? { ...msg, is_pinned: true }
              : msg
          )
        );
        
        toast.success("Message pinned");
      }
    } catch (error) {
      console.error("Error pinning/unpinning message:", error);
      toast.error("Failed to pin/unpin message");
    } finally {
      setPinningMessageId(null);
    }
  };

  // Handle message deletion
  const handleDeleteMessage = async (messageId) => {
    // Show loading toast
    const deleteToast = safeToast.loading("Deleting message...");

    console.log('Deleting message in TeamChat:', messageId);

    try {
      // Optimistically update the message to show as deleted
      setMessages((prev) => {
        const updated = prev.map((msg) =>
          msg.message_id === messageId
            ? {
                ...msg,
                isDeleted: true,
                originalContent: msg.originalContent || msg.content,
                content: "This message was deleted",
              }
            : msg
        );
        console.log('Messages after optimistic delete:', updated.find(m => m.message_id === messageId));
        return updated;
      });

      await axios.delete(
        `${import.meta.env.VITE_BASE_URL}/api/messages/${messageId}`,
        { withCredentials: true }
      );

      safeToast.success("Message deleted", { id: deleteToast });
    } catch (error) {
      console.error("Error deleting message:", error);

      // Revert the optimistic update on error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId && msg.isDeleted
            ? {
                ...msg,
                isDeleted: false,
                content: msg.originalContent || msg.content,
              }
            : msg
        )
      );

      safeToast.error("Failed to delete message", { id: deleteToast });
    }
  };

  // Handle message editing
  const handleEditMessage = (message) => {
    setEditingMessage(message);
    setNewMessage(message.content);
    textareaRef.current?.focus();
  };

  // Handle reply
  const handleReply = (message) => {
    setReplyingTo(message);
    textareaRef.current?.focus();
  };

  // Handle file download
  const handleFileDownload = async (fileUrl, fileName) => {
    if (!fileUrl) {
      safeToast.error("File URL is not available");
      return;
    }

    const safeFileName = fileName || "download";
    const downloadToast = safeToast.loading(`Downloading ${safeFileName}...`);

    try {
      const link = document.createElement("a");
      link.href = fileUrl;
      link.download = safeFileName;
      link.target = "_blank";
      link.rel = "noopener noreferrer";

      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 100);

      safeToast.success(`Download started for ${safeFileName}`, {
        id: downloadToast,
      });
    } catch (error) {
      console.error("Download error:", error);

      try {
        window.open(fileUrl, "_blank");
        safeToast.success(`Opening ${safeFileName} in new tab`, {
          id: downloadToast,
        });
      } catch (fallbackError) {
        console.error("Fallback error:", fallbackError);
        safeToast.error(`Download failed: ${error.message}`, {
          id: downloadToast,
        });
      }
    }
  };

  // Helper function to determine if file can be viewed inline
  const canViewInline = (fileType, fileName) => {
    if (!fileType && !fileName) return false;

    // Check by MIME type
    if (fileType) {
      if (fileType.includes("pdf")) return true;
      if (fileType.startsWith("image/")) return true;
      if (fileType.startsWith("text/")) return true;
      if (fileType.startsWith("video/")) return true;
      if (fileType.startsWith("audio/")) return true;
      if (fileType.includes("json")) return true;
      if (fileType.includes("xml")) return true;
    }

    // Check by file extension (expanded list)
    if (fileName) {
      const extension = fileName.split(".").pop()?.toLowerCase();
      const viewableExtensions = [
        // Documents
        "pdf",
        // Text files
        "txt",
        "md",
        "json",
        "xml",
        "csv",
        "html",
        "htm",
        "css",
        // Images (browser can display)
        "jpg",
        "jpeg",
        "png",
        "gif",
        "bmp",
        "webp",
        "svg",
        // Videos (browser can play)
        "mp4",
        "webm",
        "ogg",
        // Audio (browser can play)
        "mp3",
        "wav",
        "ogg",
        "m4a",
      ];
      return viewableExtensions.includes(extension);
    }

    return false;
  };

  // Get file icon based on file type
  const getFileIcon = (fileType, fileName) => {
    // First check by MIME type
    if (fileType?.startsWith("image/")) return "🖼️";
    if (fileType?.startsWith("video/")) return "🎬";
    if (fileType?.startsWith("audio/")) return "🎵";
    if (fileType?.includes("pdf")) return "📄";
    if (fileType?.includes("document") || fileType?.includes("word"))
      return "📝";
    if (fileType?.includes("spreadsheet") || fileType?.includes("excel"))
      return "📊";
    if (fileType?.includes("presentation") || fileType?.includes("powerpoint"))
      return "📽️";
    if (fileType?.includes("zip") || fileType?.includes("compressed"))
      return "🗜️";

    // Fallback to file extension (expanded)
    if (fileName) {
      const extension = fileName.split(".").pop()?.toLowerCase();
      switch (extension) {
        // Documents
        case "pdf":
          return "📄";
        case "doc":
        case "docx":
        case "odt":
          return "📝";
        case "xls":
        case "xlsx":
        case "ods":
          return "📊";
        case "ppt":
        case "pptx":
        case "odp":
          return "📽️";

        // Audio
        case "mp3":
        case "wav":
        case "ogg":
        case "m4a":
        case "aac":
        case "flac":
        case "wma":
          return "🎵";

        // Video
        case "mp4":
        case "avi":
        case "mov":
        case "wmv":
        case "flv":
        case "webm":
        case "mkv":
        case "m4v":
          return "🎬";

        // Images
        case "jpg":
        case "jpeg":
        case "png":
        case "gif":
        case "bmp":
        case "webp":
        case "svg":
        case "ico":
        case "tiff":
        case "tif":
          return "🖼️";

        // Archives
        case "zip":
        case "rar":
        case "7z":
        case "tar":
        case "gz":
        case "bz2":
          return "🗜️";

        // Text files
        case "txt":
        case "rtf":
        case "md":
          return "📝";
        case "csv":
          return "📊";
        case "json":
        case "xml":
        case "html":
        case "htm":
        case "css":
          return "💻";

        // Design files
        case "psd":
        case "ai":
        case "eps":
        case "sketch":
        case "fig":
          return "🎨";

        default:
          return "📎";
      }
    }

    return "📎";
  };

  // Format file size
  const formatFileSize = (bytes) => {
    if (!bytes) return "";
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Format timestamp with accurate timing and timezone handling
  const formatTime = (timestamp) => {
    if (!timestamp) return "";

    // Handle different timestamp formats and ensure proper parsing
    let date;
    try {
      if (typeof timestamp === "string") {
        // Handle ISO string formats, ensure UTC parsing if no timezone info
        if (
          timestamp.includes("T") &&
          !timestamp.includes("Z") &&
          !timestamp.includes("+") &&
          !timestamp.includes("-", 10)
        ) {
          // Assume UTC if no timezone specified in ISO format
          date = new Date(timestamp + "Z");
        } else {
          date = new Date(timestamp);
        }
      } else if (typeof timestamp === "number") {
        // Handle Unix timestamp (seconds or milliseconds)
        date =
          timestamp > 1000000000000
            ? new Date(timestamp)
            : new Date(timestamp * 1000);
      } else {
        date = new Date(timestamp);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn("Invalid timestamp:", timestamp);
        return "Invalid date";
      }
    } catch (error) {
      console.warn("Error parsing timestamp:", timestamp, error);
      return "Invalid date";
    }

    const now = new Date();
    const diff = now.getTime() - date.getTime();

    // Handle future dates (clock sync issues)
    if (diff < 0) {
      const futureDiff = Math.abs(diff);
      if (futureDiff < 30000) return "Just now"; // Within 30 seconds, assume clock sync issue
      return "Just now"; // Don't show future times
    }

    // Less than 30 seconds
    if (diff < 30000) return "Just now";

    // Less than 1 minute
    if (diff < 60000) return "Less than a minute ago";

    // Less than 1 hour
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
    }

    // Same day
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    }

    // Yesterday
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday at ${date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })}`;
    }

    // Less than 7 days
    if (diff < 604800000) {
      const days = Math.floor(diff / 86400000);
      return `${days} day${days === 1 ? "" : "s"} ago`;
    }

    // More than 7 days
    const currentYear = now.getFullYear();
    const messageYear = date.getFullYear();

    if (currentYear === messageYear) {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    } else {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    }
  };

  // Render message content with mentions
  const renderMessageContent = (content) => {
    if (!content) return "";

    let processedContent = content;

    // Replace mentions for each member
    channelMembers.forEach((member) => {
      const mentionPattern = new RegExp(
        `@${member.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s|$)`,
        "gi"
      );
      processedContent = processedContent.replace(mentionPattern, (match) => {
        return `<span class="inline-flex items-center text-blue-600 font-semibold bg-blue-100 px-2 py-1 rounded-md border border-blue-200 text-sm">${match}</span>`;
      });
    });

    return processedContent;
  };

  // Handle drag and drop for the entire chat area
  const handleChatDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  };

  const handleChatDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    // Only hide drag overlay if we're leaving the main container
    if (!e.currentTarget.contains(e.relatedTarget)) {
      setDragOver(false);
    }
  };

  const handleChatDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(Array.from(e.dataTransfer.files));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div
      className="h-full flex flex-col bg-gradient-to-b from-gray-50 to-white relative"
      onDragOver={handleChatDragOver}
      onDragLeave={handleChatDragLeave}
      onDrop={handleChatDrop}
    >
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 messages-smooth-scroll">
        {/* Welcome Message */}
        <div className="bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 border border-purple-200 rounded-2xl p-8 text-center shadow-sm">
          <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-purple-300 shadow-lg">
            <Hash size={28} className="text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">
            Welcome to #{channelName}
          </h2>
          <p className="text-gray-700 text-lg">
            This is the beginning of the{" "}
            <span className="text-purple-600 font-semibold">
              #{channelName}
            </span>{" "}
            channel. Start the conversation! 🚀
          </p>
        </div>

        {/* Messages and Polls Combined */}
        {[...messages, ...polls.map(poll => ({ ...poll, isPoll: true, created_at: poll.created_at, user_id: poll.created_by }))]
          .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
          .map((item, index, sortedItems) => {
          
          // Handle polls
          if (item.isPoll) {
            const isOwnPoll = item.created_by === user.user_id;
            return (
              <div key={`poll-${item.poll_id}`} className="mb-4">
                <PollDisplay
                  poll={item}
                  onVote={(updatedPoll) => {
                    setPolls((prev) =>
                      prev.map((p) =>
                        p.poll_id === updatedPoll.poll_id ? updatedPoll : p
                      )
                    );
                  }}
                  onDelete={isOwnPoll ? async () => {
                    try {
                      await axios.delete(
                        `${import.meta.env.VITE_BASE_URL}/api/polls/${item.poll_id}`,
                        { withCredentials: true }
                      );
                      setPolls((prev) => prev.filter((p) => p.poll_id !== item.poll_id));
                      toast.success("Poll deleted");
                    } catch (error) {
                      console.error("Error deleting poll:", error);
                      toast.error("Failed to delete poll");
                    }
                  } : null}
                  currentUserId={user.user_id}
                  onReaction={null}
                  onReply={null}
                  reactions={[]}
                />
              </div>
            );
          }
          
          // Handle messages
          const message = item;
          const showAvatar =
            index === 0 || sortedItems[index - 1].user_id !== message.user_id;
          const isOwnMessage = message.user_id === user.user_id;

          return (
            <div
              key={message.message_id}
              ref={(el) => {
                if (el) messageRefs.current[message.message_id] = el;
              }}
              className={`group transition-all duration-200 hover:bg-gray-50 rounded-lg p-2 -m-2 ${
                showAvatar ? "mt-4" : "mt-1"
              } ${
                message.isNew
                  ? "animate-in slide-in-from-bottom-2 duration-300"
                  : ""
              }`}
            >
              <div
                className={`flex gap-2 ${
                  isOwnMessage ? "flex-row-reverse" : ""
                }`}
              >
                {/* Avatar */}
                {showAvatar ? (
                  message.user_photo ? (
                    <img
                      src={message.user_photo}
                      alt={message.user_name}
                      className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-md flex-shrink-0 transition-transform hover:scale-105"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm border-2 border-white shadow-md flex-shrink-0 transition-transform hover:scale-105">
                      {message.user_name?.charAt(0) || "U"}
                    </div>
                  )
                ) : (
                  <div className="w-10 flex-shrink-0"></div>
                )}

                <div
                  className={`flex-1 min-w-0 ${
                    isOwnMessage ? "text-right" : ""
                  }`}
                >
                  {/* Header with action buttons */}
                  {(showAvatar || !message.isDeleted) && (
                    <div
                      className={`flex items-center gap-2 mb-1 justify-start ${
                        isOwnMessage ? "flex-row-reverse" : ""
                      }`}
                    >
                      {showAvatar && (
                        <div
                          className={`flex items-center gap-2 ${
                            isOwnMessage ? "flex-row-reverse" : ""
                          }`}
                        >
                          <span className="font-semibold text-gray-900 text-sm">
                            {isOwnMessage ? "You" : message.user_name}
                          </span>
                          <span className="text-xs text-gray-500">
                            {formatTime(message.created_at)}
                          </span>
                        </div>
                      )}

                      {/* Message actions in header */}
                      {!message.isDeleted && (
                        <div className="opacity-0 group-hover:opacity-100 transition-all duration-200">
                          <div className="bg-white border border-gray-200 rounded-lg shadow-lg flex items-center gap-1 p-1">
                          <button
                            onClick={() =>
                              handleReaction(message.message_id, "👍")
                            }
                            className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                            title="Like"
                          >
                            <ThumbsUp size={14} />
                          </button>
                          <button
                            onClick={() =>
                              handleReaction(message.message_id, "❤️")
                            }
                            className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-red-600 transition-colors cursor-pointer"
                            title="Love"
                          >
                            <Heart size={14} />
                          </button>
                          <button
                            onClick={() => handleReply(message)}
                            className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                            title="Reply"
                          >
                            <Reply size={14} />
                          </button>
                          {!message.isDeleted && (
                            <>
                              <button
                                onClick={() => handlePinMessage(message.message_id)}
                                disabled={pinningMessageId === message.message_id}
                                className={`p-2 hover:bg-purple-50 rounded-md transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                                  message.is_pinned 
                                    ? 'text-purple-600' 
                                    : 'text-gray-500 hover:text-purple-600'
                                }`}
                                title={message.is_pinned ? "Unpin message" : "Pin message"}
                              >
                                {pinningMessageId === message.message_id ? (
                                  <Loader2 size={14} className="animate-spin" />
                                ) : (
                                  <Pin size={14} className={message.is_pinned ? 'fill-current' : ''} />
                                )}
                              </button>
                            </>
                          )}
                          {isOwnMessage && !message.isDeleted && (
                            <>
                              <div className="w-px h-6 bg-gray-200 mx-1"></div>
                              <button
                                onClick={() => handleEditMessage(message)}
                                className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                                title="Edit"
                              >
                                <Edit2 size={14} />
                              </button>
                              <button
                                onClick={() => {
                                  // Store original content before deletion for potential recovery
                                  setMessages((prev) =>
                                    prev.map((msg) =>
                                      msg.message_id === message.message_id
                                        ? {
                                            ...msg,
                                            originalContent: msg.content,
                                          }
                                        : msg
                                    )
                                  );
                                  handleDeleteMessage(message.message_id);
                                }}
                                className="p-2 hover:bg-red-50 rounded-md text-gray-500 hover:text-red-600 transition-colors cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 size={14} />
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                    </div>
                  )}

                  {/* Reply indicator */}
                  {message.reply_to && (
                    <div
                      className={`bg-gray-100 border-l-4 border-gray-300 pl-3 py-2 mb-2 rounded-r ${
                        isOwnMessage ? "bg-blue-50 border-blue-300" : ""
                      }`}
                    >
                      <div className="text-xs text-gray-600 mb-1">
                        Replying to {message.reply_to_user_name}
                      </div>
                      <div className="text-sm text-gray-800 truncate">
                        {message.reply_to_content}
                      </div>
                    </div>
                  )}

                  {/* Message content wrapper */}
                  <div
                    className={`flex flex-col ${
                      isOwnMessage ? "items-end" : "items-start"
                    }`}
                  >
                    <div className="min-w-0">
                      {message.isDeleted ? (
                        <div
                          className={`text-sm italic p-3 rounded-2xl ${
                            isOwnMessage
                              ? "bg-gray-200 text-gray-500"
                              : "bg-gray-100 text-gray-500"
                          }`}
                        >
                          {message.content}
                        </div>
                      ) : message.file_url ? (
                        <div
                          className={`relative rounded-2xl p-4 inline-block max-w-xs sm:max-w-md shadow-sm ${
                            isOwnMessage
                              ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white ml-auto rounded-br-md"
                              : "bg-white border border-gray-200 rounded-bl-md"
                          }`}
                        >
                          {/* Pinned indicator badge for files */}
                          {message.is_pinned && (
                            <div className={`absolute -top-2 -left-2 ${
                              isOwnMessage ? '-right-2 -left-auto' : ''
                            }`}>
                              <div className="bg-purple-600 text-white rounded-full p-1 shadow-lg">
                                <Pin size={10} className="fill-current" />
                              </div>
                            </div>
                          )}
                          {message.file_type?.startsWith("image/") ? (
                            <div className="relative group">
                              <img
                                src={message.file_url}
                                alt={message.file_name}
                                className="max-w-full h-auto rounded cursor-pointer transition-transform hover:scale-105"
                                onClick={() => {
                                  // For images, try direct URL first, fallback to view proxy if needed
                                  window.open(message.file_url, "_blank");
                                }}
                                onError={(e) => {
                                  // If image fails to load, try the view proxy
                                  const viewUrl = `${
                                    import.meta.env.VITE_BASE_URL
                                  }/api/files/view?url=${encodeURIComponent(
                                    message.file_url
                                  )}&filename=${encodeURIComponent(
                                    message.file_name
                                  )}`;
                                  e.target.src = viewUrl;
                                }}
                              />
                              <div className="absolute top-2 right-2 opacity-100 transition-opacity">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();

                                    handleFileDownload(
                                      message.file_url,
                                      message.file_name
                                    );
                                  }}
                                  className="p-2 bg-black bg-opacity-50 hover:bg-opacity-70 rounded-full text-white transition-all cursor-pointer"
                                  title="Download image"
                                >
                                  <Download size={16} />
                                </button>
                              </div>
                              {message.file_name && (
                                <div className="mt-2 text-xs opacity-75">
                                  {message.file_name}
                                </div>
                              )}
                            </div>
                          ) : message.file_type?.startsWith("video/") ? (
                            <div className="relative">
                              <video
                                src={message.file_url}
                                controls
                                className="max-w-full h-auto rounded"
                                preload="metadata"
                              >
                                Your browser does not support the video tag.
                              </video>
                              <div className="flex items-center justify-between mt-2">
                                <div className="flex-1 min-w-0">
                                  <div
                                    className={`text-sm font-medium truncate ${
                                      isOwnMessage
                                        ? "text-white"
                                        : "text-gray-900"
                                    }`}
                                  >
                                    {message.file_name}
                                  </div>
                                  <div
                                    className={`text-xs ${
                                      isOwnMessage
                                        ? "text-blue-100"
                                        : "text-gray-500"
                                    }`}
                                  >
                                    {formatFileSize(message.file_size)}
                                  </div>
                                </div>
                                <button
                                  onClick={() =>
                                    handleFileDownload(
                                      message.file_url,
                                      message.file_name
                                    )
                                  }
                                  className={`p-1 rounded cursor-pointer ml-2 ${
                                    isOwnMessage
                                      ? "hover:bg-blue-600"
                                      : "hover:bg-gray-200"
                                  }`}
                                  title="Download video"
                                >
                                  <Download
                                    size={16}
                                    className={
                                      isOwnMessage
                                        ? "text-white"
                                        : "text-gray-600"
                                    }
                                  />
                                </button>
                              </div>
                            </div>
                          ) : message.file_type?.startsWith("audio/") ? (
                            <div className="space-y-2">
                              <audio
                                src={message.file_url}
                                controls
                                className="w-full"
                                preload="metadata"
                              >
                                Your browser does not support the audio tag.
                              </audio>
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-lg">
                                    {getFileIcon(
                                      message.file_type,
                                      message.file_name
                                    )}
                                  </span>
                                  <div className="flex-1 min-w-0">
                                    <div
                                      className={`text-sm font-medium truncate ${
                                        isOwnMessage
                                          ? "text-white"
                                          : "text-gray-900"
                                      }`}
                                    >
                                      {message.file_name}
                                    </div>
                                    <div
                                      className={`text-xs ${
                                        isOwnMessage
                                          ? "text-blue-100"
                                          : "text-gray-500"
                                      }`}
                                    >
                                      {formatFileSize(message.file_size)}
                                    </div>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() =>
                                      handleFileDownload(
                                        message.file_url,
                                        message.file_name
                                      )
                                    }
                                    className={`p-1 rounded cursor-pointer ${
                                      isOwnMessage
                                        ? "hover:bg-blue-600"
                                        : "hover:bg-gray-200"
                                    }`}
                                    title="Download audio"
                                  >
                                    <Download
                                      size={16}
                                      className={
                                        isOwnMessage
                                          ? "text-white"
                                          : "text-gray-600"
                                      }
                                    />
                                  </button>
                                  {isOwnMessage && (
                                    <button
                                      onClick={() => handleDeleteMessage(message.message_id)}
                                      className="p-1 rounded cursor-pointer hover:bg-red-600 text-white"
                                      title="Delete audio message"
                                    >
                                      <Trash2 size={16} />
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-3">
                              <div className="flex-shrink-0">
                                <span className="text-2xl">
                                  {getFileIcon(
                                    message.file_type,
                                    message.file_name
                                  )}
                                </span>
                              </div>
                              <div className="flex-1 min-w-0">
                                <div
                                  className={`text-sm font-medium truncate ${
                                    isOwnMessage
                                      ? "text-white"
                                      : "text-gray-900"
                                  }`}
                                >
                                  {message.file_name}
                                </div>
                                <div
                                  className={`text-xs ${
                                    isOwnMessage
                                      ? "text-blue-100"
                                      : "text-gray-500"
                                  }`}
                                >
                                  {formatFileSize(message.file_size)}
                                  {message.file_type && (
                                    <span className="ml-1">
                                      •{" "}
                                      {message.file_type
                                        .split("/")[1]
                                        ?.toUpperCase()}
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="flex gap-1">
                                <button
                                  onClick={() => {
                                    // For local files or viewable files, use the view proxy
                                    if (
                                      message.file_url.includes(
                                        "/api/files/local/"
                                      ) ||
                                      canViewInline(
                                        message.file_type,
                                        message.file_name
                                      )
                                    ) {
                                      const viewUrl = `${
                                        import.meta.env.VITE_BASE_URL
                                      }/api/files/view?url=${encodeURIComponent(
                                        message.file_url
                                      )}&filename=${encodeURIComponent(
                                        message.file_name
                                      )}`;
                                      window.open(viewUrl, "_blank");
                                    } else {
                                      // For other files, try direct URL
                                      window.open(message.file_url, "_blank");
                                    }
                                  }}
                                  className={`p-2 rounded cursor-pointer ${
                                    isOwnMessage
                                      ? "hover:bg-blue-600"
                                      : "hover:bg-gray-200"
                                  }`}
                                  title="Open file"
                                >
                                  <File
                                    size={16}
                                    className={
                                      isOwnMessage
                                        ? "text-white"
                                        : "text-gray-600"
                                    }
                                  />
                                </button>
                                <button
                                  onClick={() =>
                                    handleFileDownload(
                                      message.file_url,
                                      message.file_name
                                    )
                                  }
                                  className={`p-2 rounded cursor-pointer ${
                                    isOwnMessage
                                      ? "hover:bg-blue-600"
                                      : "hover:bg-gray-200"
                                  }`}
                                  title="Download file"
                                >
                                  <Download
                                    size={16}
                                    className={
                                      isOwnMessage
                                        ? "text-white"
                                        : "text-gray-600"
                                    }
                                  />
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="relative inline-block">
                          <div
                            className={`text-sm leading-relaxed break-words p-4 rounded-2xl shadow-sm transition-all duration-200 inline-block max-w-xs sm:max-w-md lg:max-w-lg ${
                              message.isDeleted
                                ? "message-deleted message-delete-animation"
                                : isOwnMessage
                                ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white ml-auto rounded-br-md hover:shadow-md"
                                : "bg-white text-gray-800 rounded-bl-md border border-gray-200 hover:shadow-md hover:border-gray-300"
                            }`}
                            dangerouslySetInnerHTML={{
                              __html: message.isDeleted
                                ? message.content
                                : renderMessageContent(message.content),
                            }}
                          />
                          {/* Pinned indicator badge for text messages */}
                          {message.is_pinned && !message.isDeleted && (
                            <div className={`absolute -top-2 -left-2 ${
                              isOwnMessage ? '-right-2 -left-auto' : ''
                            }`}>
                              <div className="bg-purple-600 text-white rounded-full p-1 shadow-lg">
                                <Pin size={10} className="fill-current" />
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Reactions */}
                      {!message.isDeleted && (
                        <div className="mt-1">
                          <MessageReactions
                            reactions={message.reactions || []}
                            onReactionClick={(emoji) =>
                              handleReaction(message.message_id, emoji)
                            }
                            currentUserId={user.user_id}
                            isOwnMessage={isOwnMessage}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        <div ref={messagesEndRef} />
      </div>

      {/* Reply indicator */}
      {replyingTo && (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-t border-blue-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-full">
                <Reply size={16} className="text-blue-600" />
              </div>
              <div>
                <span className="text-sm font-semibold text-blue-800">
                  Replying to {replyingTo.user_name}
                </span>
                <div className="text-sm text-gray-700 truncate max-w-xs bg-white px-3 py-1 rounded-lg mt-1 border border-blue-200">
                  {replyingTo.content}
                </div>
              </div>
            </div>
            <button
              onClick={() => setReplyingTo(null)}
              className="p-2 hover:bg-blue-100 rounded-full transition-colors cursor-pointer"
            >
              <X size={16} className="text-blue-600" />
            </button>
          </div>
        </div>
      )}

      {/* Edit indicator */}
      {editingMessage && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-t border-amber-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-100 rounded-full">
                <Edit2 size={16} className="text-amber-600" />
              </div>
              <span className="text-sm font-semibold text-amber-800">
                Editing message
              </span>
            </div>
            <button
              onClick={() => {
                setEditingMessage(null);
                setNewMessage("");
              }}
              className="p-2 hover:bg-amber-100 rounded-full transition-colors cursor-pointer"
            >
              <X size={16} className="text-amber-600" />
            </button>
          </div>
        </div>
      )}

      {/* Message Input */}
      <div className="border-t border-gray-200 bg-white p-3 sm:p-6 shadow-lg relative">
        {/* Typing indicator - positioned above input */}
        {typingUsers.length > 0 && (
          <div className="absolute bottom-full left-0 right-0 mb-2 px-3 sm:px-6">
            <TypingIndicator users={typingUsers} />
          </div>
        )}

        <form onSubmit={sendMessage} className="relative">
          {/* Mentions dropdown - positioned above input */}
          {showMentions && (
            <div
              ref={mentionsRef}
              className="absolute bottom-full left-0 right-0 mb-2 z-[9999] max-w-full sm:max-w-md"
            >
              <MentionsList
                members={channelMembers}
                query={mentionQuery}
                selectedIndex={selectedMentionIndex}
                onSelect={handleMentionSelect}
              />
            </div>
          )}

          <div className="bg-white border-2 border-gray-200 rounded-2xl focus-within:border-purple-500 focus-within:ring-4 focus-within:ring-purple-100 transition-all duration-200 shadow-sm hover:shadow-md">
            <textarea
              ref={textareaRef}
              value={newMessage}
              onChange={handleInputChange}
              onKeyDown={(e) => {
                if (showMentions) {
                  const filteredMembers = channelMembers
                    .filter((member) =>
                      member.name
                        .toLowerCase()
                        .includes(mentionQuery.toLowerCase())
                    )
                    .slice(0, 5);

                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setSelectedMentionIndex((prev) =>
                      prev < filteredMembers.length - 1 ? prev + 1 : 0
                    );
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setSelectedMentionIndex((prev) =>
                      prev > 0 ? prev - 1 : filteredMembers.length - 1
                    );
                  } else if (e.key === "Enter" || e.key === "Tab") {
                    e.preventDefault();
                    if (filteredMembers[selectedMentionIndex]) {
                      handleMentionSelect(
                        filteredMembers[selectedMentionIndex]
                      );
                    }
                  } else if (e.key === "Escape") {
                    setShowMentions(false);
                    setMentionQuery("");
                  }
                } else if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage(e);
                }
              }}
              placeholder={`Message #${channelName}...`}
              className="w-full bg-transparent text-gray-900 placeholder-gray-400 px-3 sm:px-6 py-3 sm:py-4 pr-20 sm:pr-24 resize-none outline-none text-sm sm:text-base max-h-[120px] leading-relaxed"
              rows="1"
              disabled={sending}
            />

            <div className="flex items-center justify-between px-2 sm:px-4 pb-3 sm:pb-4">
              <div className="flex items-center gap-1 sm:gap-3">
                {/* Voice Message Button */}
                <button
                  type="button"
                  onClick={() => setShowVoiceRecorder(true)}
                  className="p-1.5 sm:p-2 hover:bg-blue-100 rounded-xl text-gray-600 hover:text-blue-600 transition-all duration-200 cursor-pointer group"
                  title="Record voice message"
                >
                  <Mic size={18} className="sm:w-5 sm:h-5" />
                </button>

                {/* Poll Button */}
                <button
                  type="button"
                  onClick={() => setShowPollModal(true)}
                  className="p-1.5 sm:p-2 hover:bg-green-100 rounded-xl text-gray-600 hover:text-green-600 transition-all duration-200 cursor-pointer group"
                  title="Create poll"
                >
                  <BarChart3 size={18} className="sm:w-5 sm:h-5" />
                </button>

                <div className="relative" ref={emojiPickerRef}>
                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="p-1.5 sm:p-2 hover:bg-yellow-100 rounded-xl text-gray-600 hover:text-yellow-600 transition-all duration-200 cursor-pointer"
                    title="Add emoji"
                  >
                    <Smile size={18} className="sm:w-5 sm:h-5" />
                  </button>
                  {showEmojiPicker && (
                    <div className="absolute bottom-full left-0 mb-2 z-50">
                      <EmojiPicker onEmojiSelect={handleEmojiSelect} />
                    </div>
                  )}
                </div>

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowFileUpload(true)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      fileInputRef.current?.click();
                    }}
                    className="p-1.5 sm:p-2 hover:bg-purple-100 rounded-xl text-gray-600 hover:text-purple-600 transition-all duration-200 cursor-pointer"
                    title="Attach files - Click to browse, right-click for quick upload, or drag & drop files anywhere"
                  >
                    <Paperclip size={18} className="sm:w-5 sm:h-5" />
                  </button>

                  {/* Quick file input for single file uploads */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.length) {
                        handleFileUpload(Array.from(e.target.files));
                        e.target.value = ""; // Reset input
                      }
                    }}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={!newMessage.trim() || sending}
                className={`flex items-center gap-1.5 sm:gap-3 px-3 sm:px-6 py-2 sm:py-3 rounded-xl font-semibold text-xs sm:text-sm transition-all duration-200 shadow-sm ${
                  newMessage.trim() && !sending
                    ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transform hover:scale-105 cursor-pointer"
                    : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}
              >
                {sending ? (
                  <div className="animate-spin rounded-full h-3 w-3 sm:h-4 sm:w-4 border-t-2 border-white"></div>
                ) : (
                  <Send size={14} className="sm:w-4 sm:h-4" />
                )}
                <span className="hidden sm:inline">
                  {editingMessage ? "Update" : "Send"}
                </span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Drag and Drop Overlay */}
      {dragOver && (
        <div className="absolute inset-0 bg-purple-500/10 backdrop-blur-sm border-2 border-dashed border-purple-400 rounded-lg flex items-center justify-center z-40">
          <div className="text-center p-8">
            <div className="text-6xl mb-4">📁</div>
            <h3 className="text-xl font-semibold text-purple-700 mb-2">
              Drop files here
            </h3>
            <p className="text-purple-600">
              Release to upload files to #{channelName}
            </p>
          </div>
        </div>
      )}

      {/* File Upload Modal */}
      {showFileUpload && (
        <FileUpload
          onUpload={handleFileUpload}
          onClose={() => setShowFileUpload(false)}
          maxFiles={5}
          maxSize={10 * 1024 * 1024} // 10MB
        />
      )}

      {/* Voice Recorder Modal */}
      {showVoiceRecorder && (
        <VoiceRecorder
          onSend={handleVoiceMessage}
          onCancel={() => setShowVoiceRecorder(false)}
        />
      )}

      {/* Poll Creation Modal */}
      {showPollModal && (
        <QuickPoll
          channelId={channelId}
          onClose={() => setShowPollModal(false)}
          onPollCreated={() => {
            // Don't add poll here - socket event will handle it for everyone including creator
            setShowPollModal(false);
            // Toast is already shown in QuickPoll component
          }}
        />
      )}
    </div>
  );
};

export default TeamChat;
