import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useAuth } from "../context/AuthContext";
import { useSocket } from "../context/SocketContext";
import { useUnread } from "../context/UnreadContext";
import { useSearchParams } from "react-router";
import axios from "axios";
import {
  Search,
  MessageCircle,
  CheckCheck,
  Send,
  Smile,
  Paperclip,
  Reply,
  Edit2,
  Trash2,
  Download,
  File,
  X,
  Heart,
  ThumbsUp,
  ArrowLeft,
  Plus,
  PanelLeftClose,
  PanelLeftOpen,
  Pin,
  Mic,
  Loader2,
} from "lucide-react";
import { toast } from "react-hot-toast";
import EmojiPicker from "./EmojiPicker";
import MessageReactions from "./MessageReactions";
import TypingIndicator from "./TypingIndicator";
import FileUpload from "./FileUpload";
import VoiceRecorder from "./VoiceRecorder";
import ConfirmationModal from "./ConfirmationModal";

const Messages = () => {
  const { user } = useAuth();
  const { socket, isConnected } = useSocket();
  const { markDirectMessagesAsRead } = useUnread();
  const [searchParams, setSearchParams] = useSearchParams();

  // State for conversations list
  const [conversations, setConversations] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  // State for selected conversation
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [messagesLoading, setMessagesLoading] = useState(false);

  // State for message input
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [editingMessage, setEditingMessage] = useState(null);
  const [typingUsers, setTypingUsers] = useState([]);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // State for new conversation
  const [showNewConversation, setShowNewConversation] = useState(false);
  const [organizationMembers, setOrganizationMembers] = useState([]);
  const [memberSearchQuery, setMemberSearchQuery] = useState("");

  // State for sidebar visibility
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  // State for conversation actions
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [conversationToDelete, setConversationToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // State for navigation control
  const [isNavigatingBack, setIsNavigatingBack] = useState(false);
  
  // State for pinning messages
  const [pinningMessageId, setPinningMessageId] = useState(null);

  // Refs
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const emojiPickerRef = useRef(null);

  // Optimized scroll to bottom for WhatsApp-like experience
  const scrollToBottom = useCallback((instant = false) => {
    if (messagesEndRef.current) {
      if (instant) {
        // Instant scroll for real-time messages
        messagesEndRef.current.scrollIntoView({ behavior: "auto" });
      } else {
        // Smooth scroll for user actions
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, []);

  // Fetch conversations
  const fetchConversations = useCallback(
    async (silent = false) => {
      if (!user?.user_id) return;

      try {
        if (!silent) setLoading(true);
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/conversations`,
          { withCredentials: true }
        );
        setConversations(response.data.conversations || []);
      } catch (error) {
        console.error("Error fetching conversations:", error);
        if (!silent) toast.error("Failed to load conversations");
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [user?.user_id]
  );

  // Fetch messages for selected conversation
  const fetchMessages = useCallback(
    async (otherUserId) => {
      if (!user?.user_id || !otherUserId) return;

      try {
        setMessagesLoading(true);
        const response = await axios.get(
          `${
            import.meta.env.VITE_BASE_URL
          }/api/direct-messages/conversations/${otherUserId}`,
          { withCredentials: true }
        );
        setMessages(response.data.messages || []);

        // Mark messages as read using the unread context
        markDirectMessagesAsRead(otherUserId);

        // Scroll to bottom after messages load
        setTimeout(scrollToBottom, 100);
      } catch (error) {
        console.error("Error fetching messages:", error);
        toast.error("Failed to load messages");
      } finally {
        setMessagesLoading(false);
      }
    },
    [user?.user_id, markDirectMessagesAsRead, scrollToBottom]
  );

  // Fetch organization members for new conversations
  const fetchOrganizationMembers = useCallback(async () => {
    if (!user?.user_id) return;

    try {
      const response = await axios.get(
        `${
          import.meta.env.VITE_BASE_URL
        }/api/direct-messages/organization/members`,
        { withCredentials: true }
      );
      setOrganizationMembers(response.data.members || []);
    } catch (error) {
      console.error("Error fetching organization members:", error);
      toast.error("Failed to load organization members");
    }
  }, [user?.user_id]);

  // Socket event handlers - Optimized for WhatsApp-like real-time experience
  useEffect(() => {
    if (!socket || !isConnected || !user?.user_id) {
      return;
    }

    // Debounce function to prevent rapid updates - reduced wait time for faster response
    const debounce = (func, wait) => {
      let timeout;
      return function executedFunction(...args) {
        const later = () => {
          clearTimeout(timeout);
          func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    };

    // Listen for new direct messages - Optimized for instant WhatsApp-like updates
    const handleNewDirectMessage = (message) => {
      // Determine if this message is for the current conversation
      const isCurrentConversation =
        selectedConversation &&
        (message.sender_id === selectedConversation.other_user_id ||
          message.receiver_id === selectedConversation.other_user_id);

      // Update messages if this conversation is currently selected - instant update
      if (isCurrentConversation) {
        setMessages((prev) => {
          // Check if this message already exists (avoid duplicates from optimistic updates)
          const existingMessage = prev.find(
            (msg) =>
              msg.message_id === message.message_id ||
              (msg.isOptimistic &&
                msg.content === message.content &&
                msg.sender_id === message.sender_id &&
                msg.receiver_id === message.receiver_id &&
                Math.abs(
                  new Date(msg.created_at) - new Date(message.created_at)
                ) < 10000) // Increased time window and added more matching criteria
          );

          if (existingMessage) {
            // Replace optimistic message with real message instantly
            return prev.map((msg) =>
              msg.message_id === existingMessage.message_id
                ? { ...message, isNew: true, isOptimistic: false }
                : msg
            );
          } else {
            // Add new message instantly
            return [...prev, { ...message, isNew: true }];
          }
        });

        // Immediate instant scroll for real-time feel
        requestAnimationFrame(() => {
          scrollToBottom(true); // Instant scroll for new messages
        });

        // Remove the isNew flag after shorter animation for faster feel
        setTimeout(() => {
          setMessages((prev) =>
            prev.map((msg) =>
              msg.message_id === message.message_id
                ? { ...msg, isNew: false }
                : msg
            )
          );
        }, 500); // Reduced from 1000ms to 500ms
      }

      // Update conversations list locally with smooth animations
      setConversations((prev) => {
        const updated = [...prev];

        // Determine which user this conversation is with
        const otherUserId =
          message.sender_id === user.user_id
            ? message.receiver_id
            : message.sender_id;

        const convIndex = updated.findIndex(
          (conv) => conv.other_user_id === otherUserId
        );

        const messageContent =
          message.content ||
          (message.file_name ? `📎 ${message.file_name}` : "File");

        if (convIndex >= 0) {
          // Update existing conversation smoothly
          const existingConv = updated[convIndex];
          const updatedConv = {
            ...existingConv,
            last_message_content: messageContent,
            last_message_time: message.created_at,
            unread_count:
              message.receiver_id === user.user_id && !isCurrentConversation
                ? existingConv.unread_count + 1
                : existingConv.unread_count,
            hasNewMessage:
              !isCurrentConversation && message.sender_id !== user.user_id, // Flag for animation
          };

          // Only move to top if it's not already at the top (avoid unnecessary re-renders)
          if (convIndex === 0) {
            updated[0] = updatedConv;
          } else {
            // Move to top smoothly
            updated.splice(convIndex, 1);
            updated.unshift(updatedConv);
          }

          // Remove the new message flag after animation
          if (updatedConv.hasNewMessage) {
            setTimeout(() => {
              setConversations((prevConvs) =>
                prevConvs.map((conv) =>
                  conv.other_user_id === otherUserId
                    ? { ...conv, hasNewMessage: false }
                    : conv
                )
              );
            }, 500);
          }
        } else if (message.sender_id !== user.user_id) {
          // Add new conversation if message is from someone else
          const newConversation = {
            other_user_id: message.sender_id,
            other_user_name: message.sender_name,
            other_user_photo: message.sender_photo,
            other_user_email: "", // We don't have this from the message
            last_message_content: messageContent,
            last_message_time: message.created_at,
            unread_count: isCurrentConversation ? 0 : 1,
            hasNewMessage: true,
          };
          updated.unshift(newConversation);

          // Remove the new message flag after animation
          setTimeout(() => {
            setConversations((prevConvs) =>
              prevConvs.map((conv) =>
                conv.other_user_id === message.sender_id
                  ? { ...conv, hasNewMessage: false }
                  : conv
              )
            );
          }, 500);
        }

        return updated;
      });
    };

    // Listen for message updates - same as TeamChat
    const handleDirectMessageUpdate = (updatedMessage) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === updatedMessage.message_id ? updatedMessage : msg
        )
      );
    };

    // Listen for message deletions - same as TeamChat
    const handleDirectMessageDelete = (messageId) => {
      console.log('Socket event: direct_message_deleted', messageId);
      setMessages((prev) => {
        const updated = prev.map((msg) =>
          msg.message_id === messageId && !msg.isDeleted
            ? {
                ...msg,
                isDeleted: true,
                originalContent: msg.originalContent || msg.content,
                content: "This message was deleted",
              }
            : msg
        );
        console.log('Messages after socket delete:', updated.find(m => m.message_id === messageId));
        return updated;
      });
    };

    // Listen for typing indicators - Optimized for instant WhatsApp-like response
    const handleUserTyping = debounce((data) => {
      if (
        selectedConversation &&
        data.userId === selectedConversation.other_user_id &&
        data.userId !== user.user_id
      ) {
        setTypingUsers((prev) => {
          const existing = prev.find((u) => u.userId === data.userId);
          if (!existing) {
            return [
              ...prev,
              {
                userId: data.userId,
                userName: data.userName,
                timestamp: Date.now(),
              },
            ];
          } else {
            // Update timestamp for existing user
            return prev.map((u) =>
              u.userId === data.userId ? { ...u, timestamp: Date.now() } : u
            );
          }
        });
      }
    }, 50); // Reduced from 100ms to 50ms for faster typing indicator response

    const handleUserStoppedTyping = (data) => {
      setTypingUsers((prev) => prev.filter((u) => u.userId !== data.userId));
    };

    // Listen for reactions - same as TeamChat
    const handleReactionUpdate = (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, reactions: data.reactions || [] }
            : msg
        )
      );
    };

    // Listen for pin/unpin events
    const handleMessagePinned = (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, is_pinned: true }
            : msg
        )
      );
    };

    const handleMessageUnpinned = (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === data.messageId
            ? { ...msg, is_pinned: false }
            : msg
        )
      );
    };

    // Listen for conversation deletions
    const handleConversationDeleted = (data) => {
      // Remove the conversation from the list (outer sidebar)
      setConversations((prev) =>
        prev.filter((conv) => conv.other_user_id !== data.otherUserId)
      );

      // If the deleted conversation is currently selected, clear it (inner sidebar)
      if (selectedConversation?.other_user_id === data.otherUserId) {
        setSelectedConversation(null);
        setMessages([]);
        setSearchParams({});
      }

      // Show toast notification
      if (data.deletedBy === user.user_id) {
        toast.success("Conversation deleted successfully");
      } else {
        // The other person deleted the conversation - show a more prominent notification
        const deletedByName = data.deletedByName || "The other user";
        toast.error(
          `${deletedByName} deleted your conversation`,
          {
            duration: 5000,
            icon: '🗑️',
          }
        );
      }
    };

    // Listen for chat history cleared
    const handleChatHistoryCleared = (data) => {
      // Clear messages if this is the currently selected conversation
      if (selectedConversation?.other_user_id === data.otherUserId) {
        setMessages([]);
        setSelectedConversation(null);
        setSearchParams({});
      }

      // Remove conversation from sidebar for this user (they can start a new one)
      setConversations((prev) =>
        prev.filter((conv) => conv.other_user_id !== data.otherUserId)
      );
    };

    socket.on("new_direct_message", handleNewDirectMessage);
    socket.on("direct_message_updated", handleDirectMessageUpdate);
    socket.on("direct_message_deleted", handleDirectMessageDelete);
    socket.on("dm_user_typing", handleUserTyping);
    socket.on("dm_user_stopped_typing", handleUserStoppedTyping);
    socket.on("direct_message_reaction_updated", handleReactionUpdate);
    socket.on("direct_message_pinned", handleMessagePinned);
    socket.on("direct_message_unpinned", handleMessageUnpinned);
    socket.on("conversation_deleted", handleConversationDeleted);
    socket.on("chat_history_cleared", handleChatHistoryCleared);

    return () => {
      socket.off("new_direct_message", handleNewDirectMessage);
      socket.off("direct_message_updated", handleDirectMessageUpdate);
      socket.off("direct_message_deleted", handleDirectMessageDelete);
      socket.off("dm_user_typing", handleUserTyping);
      socket.off("dm_user_stopped_typing", handleUserStoppedTyping);
      socket.off("direct_message_reaction_updated", handleReactionUpdate);
      socket.off("direct_message_pinned", handleMessagePinned);
      socket.off("direct_message_unpinned", handleMessageUnpinned);
      socket.off("conversation_deleted", handleConversationDeleted);
      socket.off("chat_history_cleared", handleChatHistoryCleared);
    };
  }, [
    socket,
    isConnected,
    user?.user_id,
    selectedConversation?.other_user_id, // Only depend on the ID, not the entire object
    scrollToBottom,
  ]);

  // Initialize data
  useEffect(() => {
    fetchConversations();
    fetchOrganizationMembers();
  }, [fetchConversations, fetchOrganizationMembers]);

  // Remove periodic refresh - rely on real-time updates only
  // Real-time updates through socket events should handle all conversation updates

  // Handle URL parameters for direct user selection - optimized to prevent unnecessary re-renders
  useEffect(() => {
    const userParam = searchParams.get("user");
    if (
      userParam &&
      (conversations.length > 0 || organizationMembers.length > 0) &&
      !selectedConversation && // Only run if no conversation is selected
      !isNavigatingBack // Don't auto-select when navigating back
    ) {
      const userId = parseInt(userParam);
      const conversation = conversations.find(
        (conv) => conv.other_user_id === userId
      );

      if (conversation) {
        handleSelectConversation(conversation);
      } else if (organizationMembers.length > 0) {
        // If conversation doesn't exist but we have a user param,
        // try to find the user in organization members and create a conversation
        const member = organizationMembers.find((m) => m.user_id === userId);
        if (member) {
          handleStartNewConversation(member);
        }
      }
    }
  }, [
    searchParams.get("user"),
    conversations.length,
    organizationMembers.length,
    selectedConversation,
    isNavigatingBack,
  ]); // Optimized dependencies

  // Filter conversations based on search query - optimized with useMemo
  const filteredConversations = useMemo(() => {
    if (!searchQuery.trim()) {
      return conversations;
    } else {
      return conversations.filter(
        (conv) =>
          conv.other_user_name
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase()) ||
          conv.last_message_content
            ?.toLowerCase()
            .includes(searchQuery.toLowerCase())
      );
    }
  }, [conversations, searchQuery]);

  // Auto-scroll on new messages - Optimized to prevent unnecessary scrolling
  useEffect(() => {
    // Only scroll if there are messages and the last message is new or from current user
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      const shouldScroll =
        lastMessage.isNew ||
        lastMessage.sender_id === user.user_id ||
        lastMessage.isOptimistic;

      if (shouldScroll) {
        // Use requestAnimationFrame for smoother scrolling
        requestAnimationFrame(() => {
          scrollToBottom(true); // Instant scroll for better performance
        });
      }
    }
  }, [messages.length, user.user_id, scrollToBottom]); // Only depend on messages length, not entire array

  // Cleanup typing timeout
  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      if (socket && isConnected && selectedConversation) {
        socket.emit("dm_typing_stop", {
          targetUserId: selectedConversation.other_user_id,
        });
      }
    };
  }, [selectedConversation, socket, isConnected]);

  // Cleanup stale typing users
  useEffect(() => {
    const cleanupInterval = setInterval(() => {
      const now = Date.now();
      setTypingUsers((prev) =>
        prev.filter((user) => now - (user.timestamp || 0) < 5000)
      );
    }, 1000);

    return () => clearInterval(cleanupInterval);
  }, []);

  // Handle responsive behavior
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;

      setIsMobile(mobile);
      
      // On mobile, hide sidebar when conversation is selected, show when no conversation
      if (mobile) {
        if (selectedConversation) {
          setSidebarVisible(false);
        } else {
          setSidebarVisible(true);
        }
      }
      
      // On desktop, always show sidebar
      if (!mobile) {
        setSidebarVisible(true);
      }
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, [selectedConversation, isMobile]);

  // Keyboard shortcuts for sidebar toggle and close dropdowns
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Ctrl/Cmd + B to toggle sidebar (desktop only)
      if ((e.ctrlKey || e.metaKey) && e.key === "b" && !isMobile) {
        e.preventDefault();
        setSidebarVisible((prev) => !prev);
      }
      // Escape to show sidebar if hidden or close modals
      if (e.key === "Escape") {
        if (showDeleteModal) {
          setShowDeleteModal(false);
          setConversationToDelete(null);
        } else if (showNewConversation) {
          setShowNewConversation(false);
          setMemberSearchQuery("");
        } else if (!sidebarVisible && !isMobile) {
          setSidebarVisible(true);
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [sidebarVisible, isMobile, showDeleteModal]);

  // Update timestamps every 30 seconds for better accuracy - optimized to avoid unnecessary re-renders
  useEffect(() => {
    const interval = setInterval(() => {
      // Only update if there are messages and user is actively viewing
      if (messages.length > 0 && document.visibilityState === "visible") {
        // Force re-render to update timestamps only when needed
        setMessages((prev) => [...prev]);
      }
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [messages.length]); // Only depend on messages length, not the entire messages array

  // Handle conversation selection
  const handleSelectConversation = (conversation) => {
    setSelectedConversation(conversation);
    setMessages([]);
    fetchMessages(conversation.other_user_id);

    // Update URL
    setSearchParams({ user: conversation.other_user_id.toString() });

    // On mobile, hide sidebar to show chat
    if (isMobile) {
      setSidebarVisible(false);
    }
  };

  // Handle starting new conversation
  const handleStartNewConversation = (member) => {
    const existingConversation = conversations.find(
      (conv) => conv.other_user_id === member.user_id
    );

    if (existingConversation) {
      handleSelectConversation(existingConversation);
    } else {
      // Create new conversation object
      const newConversation = {
        other_user_id: member.user_id,
        other_user_name: member.name,
        other_user_photo: member.user_photo,
        other_user_email: member.email,
        last_message_content: null,
        last_message_time: null,
        unread_count: 0,
      };

      // Add to conversations list immediately
      setConversations((prev) => [newConversation, ...prev]);

      // Select the conversation
      setSelectedConversation(newConversation);
      setMessages([]);

      // Update URL
      setSearchParams({ user: member.user_id.toString() });

      // On mobile, hide sidebar to show chat
      if (isMobile) {
        setSidebarVisible(false);
      }
    }

    setShowNewConversation(false);
    setMemberSearchQuery("");
  };

  // Handle typing indicators
  const handleTypingStart = useCallback(() => {
    if (socket && isConnected && selectedConversation) {
      socket.emit("dm_typing_start", {
        targetUserId: selectedConversation.other_user_id,
        userName: user.name,
      });
    }
  }, [socket, isConnected, selectedConversation, user?.name]);

  const handleTypingStop = useCallback(() => {
    if (socket && isConnected && selectedConversation) {
      socket.emit("dm_typing_stop", {
        targetUserId: selectedConversation.other_user_id,
      });
    }
  }, [socket, isConnected, selectedConversation]);

  // Handle message input changes
  const handleInputChange = (e) => {
    const value = e.target.value;
    setNewMessage(value);

    // Handle typing indicators
    if (value.trim() !== "") {
      handleTypingStart();

      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      typingTimeoutRef.current = setTimeout(() => {
        handleTypingStop();
      }, 1500); // Optimized to 1.5 seconds for faster WhatsApp-like response
    } else {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      handleTypingStop();
    }

    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height =
        Math.min(textareaRef.current.scrollHeight, 120) + "px";
    }
  };

  // Send message with instant optimistic updates - WhatsApp-like experience
  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() && !replyingTo) return;

    const messageContent = newMessage.trim();
    const currentReplyingTo = replyingTo;

    // Clear input immediately for instant feel
    setNewMessage("");
    setReplyingTo(null);
    handleTypingStop();

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }

    setSending(true);

    // Create optimistic message for immediate UI update
    const optimisticMessage = {
      message_id: `temp-${Date.now()}-${Math.random()}`,
      content: messageContent,
      sender_id: user.user_id,
      sender_name: user.name,
      sender_photo: user.user_photo,
      receiver_id: selectedConversation.other_user_id,
      created_at: new Date().toISOString(),
      reply_to: currentReplyingTo?.message_id || null,
      reply_to_sender_name: currentReplyingTo?.sender_name || null,
      reply_to_content: currentReplyingTo?.content || null,
      isOptimistic: true,
      reactions: [],
      status: "sending", // Add sending status
    };

    try {
      const messageData = {
        content: messageContent,
        receiver_id: selectedConversation.other_user_id,
        reply_to: currentReplyingTo?.message_id || null,
      };

      if (editingMessage) {
        // Update existing message
        await axios.put(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages/${
            editingMessage.message_id
          }`,
          { content: messageContent },
          { withCredentials: true }
        );
        setEditingMessage(null);
      } else {
        // Add optimistic message immediately for instant WhatsApp-like feel
        setMessages((prev) => [...prev, optimisticMessage]);

        // Immediate smooth scroll
        requestAnimationFrame(() => {
          scrollToBottom();
        });

        // Send new message - socket will handle the real server response
        const response = await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages`,
          messageData,
          { withCredentials: true }
        );

        // Replace optimistic message with real message from server
        // The socket event will also try to add this message, so we need to handle that
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === optimisticMessage.message_id
              ? {
                  ...response.data.message,
                  isNew: true,
                  status: "sent",
                  isOptimistic: false,
                }
              : msg
          )
        );
      }
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");

      // Mark optimistic message as failed instead of removing it
      if (!editingMessage) {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === optimisticMessage.message_id
              ? { ...msg, status: "failed", isOptimistic: false }
              : msg
          )
        );
      }
    } finally {
      setSending(false);
    }
  };

  // Handle file upload with instant optimistic updates - WhatsApp-like file sharing
  const handleFileUpload = async (files) => {
    if (!selectedConversation) return;

    const uploadPromises = files.map(async (file) => {
      const fileName = file.name || "Unknown file";
      const uploadToast = toast.loading(`Uploading ${fileName}...`);

      // Create optimistic file message for immediate UI feedback
      const optimisticFileMessage = {
          message_id: `temp-file-${Date.now()}-${Math.random()}`,
          sender_id: user.user_id,
          sender_name: user.name,
          sender_photo: user.user_photo,
          receiver_id: selectedConversation.other_user_id,
          created_at: new Date().toISOString(),
          file_name: fileName,
          file_url: URL.createObjectURL(file), // Temporary local URL for preview
          file_type: file.type,
          file_size: file.size,
          content: null,
          isOptimistic: true,
          isUploading: true,
          status: "uploading",
          reactions: [],
        };

      // Add optimistic message immediately for instant feedback
      setMessages((prev) => [...prev, optimisticFileMessage]);

      // Immediate instant scroll for file uploads
      requestAnimationFrame(() => {
        scrollToBottom(true); // Instant scroll for file messages
      });

      try {
        const formData = new FormData();
        formData.append("file", file);
        formData.append("receiver_id", selectedConversation.other_user_id);

        const response = await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages/file`,
          formData,
          {
            withCredentials: true,
            headers: { "Content-Type": "multipart/form-data" },
            timeout: 60000,
            onUploadProgress: (progressEvent) => {
              if (progressEvent.total && progressEvent.loaded) {
                const percentCompleted = Math.round(
                  (progressEvent.loaded * 100) / progressEvent.total
                );
                toast.loading(`Uploading ${fileName}... ${percentCompleted}%`, {
                  id: uploadToast,
                });
              }
            },
          }
        );

        // Replace optimistic message with real message from server
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === optimisticFileMessage.message_id
              ? { ...response.data.message, isNew: true, status: "sent" }
              : msg
          )
        );

        // Clean up the temporary URL
        URL.revokeObjectURL(optimisticFileMessage.file_url);

        toast.success(`${fileName} uploaded successfully!`, {
          id: uploadToast,
        });

        return response.data;
      } catch (error) {
        console.error("Error uploading file:", error);

        // Mark optimistic message as failed instead of removing it
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === optimisticFileMessage.message_id
              ? {
                  ...msg,
                  status: "failed",
                  isUploading: false,
                  isOptimistic: false,
                }
              : msg
          )
        );

        // Clean up the temporary URL on error
        URL.revokeObjectURL(optimisticFileMessage.file_url);

        toast.error(`Failed to upload ${file.name}`);
        throw error;
      }
    });

    try {
      await Promise.all(uploadPromises);
      setShowFileUpload(false);
    } catch (error) {
      console.error("Some files failed to upload:", error);
    }
  };

  // Handle voice message upload
  const handleVoiceUpload = async (audioBlob, duration) => {
    if (!selectedConversation) return;

    // Create optimistic message for immediate UI update
    const optimisticMessage = {
      message_id: `temp-voice-${Date.now()}-${Math.random()}`,
      content: "Voice message",
      sender_id: user.user_id,
      sender_name: user.name,
      sender_photo: user.user_photo,
      receiver_id: selectedConversation.other_user_id,
      created_at: new Date().toISOString(),
      file_url: URL.createObjectURL(audioBlob), // Temporary local URL
      file_name: "voice-message.webm",
      file_type: "audio/webm",
      file_size: audioBlob.size,
      isOptimistic: true,
      reactions: [],
      status: "sending",
    };

    try {
      // Add optimistic message immediately
      setMessages((prev) => [...prev, optimisticMessage]);
      
      // Scroll to bottom
      requestAnimationFrame(() => {
        scrollToBottom();
      });

      const formData = new FormData();
      formData.append("file", audioBlob, "voice-message.webm");
      formData.append("receiver_id", selectedConversation.other_user_id);
      formData.append("is_voice", "true");
      formData.append("voice_duration", duration.toString());

      const response = await axios.post(
        `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages/file`,
        formData,
        {
          withCredentials: true,
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      // Replace optimistic message with real message from server
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === optimisticMessage.message_id
            ? {
                ...response.data.message,
                isNew: true,
                status: "sent",
                isOptimistic: false,
              }
            : msg
        )
      );

      setShowVoiceRecorder(false);
      toast.success("Voice message sent");
    } catch (error) {
      console.error("Error uploading voice message:", error);
      
      // Remove optimistic message on error
      setMessages((prev) =>
        prev.filter((msg) => msg.message_id !== optimisticMessage.message_id)
      );
      
      toast.error("Failed to send voice message");
    }
  };

  // Handle message reactions
  const handleReaction = async (messageId, emoji) => {
    // Optimistic update - update UI immediately like TeamChat
    const currentMessage = messages.find((msg) => msg.message_id === messageId);
    if (!currentMessage) return;

    const existingReactions = currentMessage.reactions || [];
    const existingReaction = existingReactions.find(
      (r) => r.emoji === emoji && r.user_id === user.user_id
    );

    let optimisticReactions;
    if (existingReaction) {
      // Remove reaction optimistically
      optimisticReactions = existingReactions.filter(
        (r) => !(r.emoji === emoji && r.user_id === user.user_id)
      );
    } else {
      // Add reaction optimistically
      optimisticReactions = [
        ...existingReactions,
        {
          emoji,
          user_id: user.user_id,
          user_name: user.name,
          created_at: new Date().toISOString(),
        },
      ];
    }

    // Update UI immediately
    setMessages((prev) =>
      prev.map((msg) =>
        msg.message_id === messageId
          ? { ...msg, reactions: optimisticReactions }
          : msg
      )
    );

    try {
      // Send to server
      const response = await axios.post(
        `${
          import.meta.env.VITE_BASE_URL
        }/api/direct-messages/messages/${messageId}/reactions`,
        { emoji },
        { withCredentials: true }
      );

      // Update with server response (in case of conflicts)
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId
            ? { ...msg, reactions: response.data.reactions || [] }
            : msg
        )
      );
    } catch (error) {
      console.error("Error adding reaction:", error);
      toast.error("Failed to add reaction");

      // Revert optimistic update on error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId
            ? { ...msg, reactions: existingReactions }
            : msg
        )
      );
    }
  };

  // Handle message deletion with smooth optimistic updates
  const handleDeleteMessage = async (messageId) => {
    // Store original message for potential revert
    const originalMessage = messages.find(
      (msg) => msg.message_id === messageId
    );
    if (!originalMessage) {
      console.error('Message not found for deletion:', messageId);
      return;
    }

    console.log('Deleting message:', messageId, originalMessage);

    try {

      // Optimistically update the message to show as deleted immediately
      setMessages((prev) => {
        const updated = prev.map((msg) =>
          msg.message_id === messageId
            ? {
                ...msg,
                isDeleted: true,
                originalContent: msg.originalContent || msg.content,
                content: "This message was deleted",
                isDeleting: true, // Add deleting state for smooth animation
              }
            : msg
        );
        console.log('Messages after optimistic delete:', updated.find(m => m.message_id === messageId));
        return updated;
      });

      // Remove deleting state after animation
      setTimeout(() => {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === messageId ? { ...msg, isDeleting: false } : msg
          )
        );
      }, 300);

      await axios.delete(
        `${
          import.meta.env.VITE_BASE_URL
        }/api/direct-messages/messages/${messageId}`,
        { withCredentials: true }
      );

      toast.success("Message deleted");
    } catch (error) {
      console.error("Error deleting message:", error);

      // Revert the optimistic update on error
      setMessages((prev) =>
        prev.map((msg) =>
          msg.message_id === messageId && msg.isDeleted
            ? {
                ...originalMessage,
                isDeleting: false,
              }
            : msg
        )
      );

      toast.error("Failed to delete message");
    }
  };

  // Handle message editing
  const handleEditMessage = (message) => {
    setEditingMessage(message);
    setNewMessage(message.content);
    textareaRef.current?.focus();
  };

  // Handle reply
  const handleReply = (message) => {
    setReplyingTo(message);
    textareaRef.current?.focus();
  };

  // Handle message pinning
  const handlePinMessage = async (messageId) => {
    if (pinningMessageId) return; // Prevent multiple simultaneous pin operations
    
    try {
      setPinningMessageId(messageId);
      const message = messages.find(m => m.message_id === messageId);
      const isPinned = message?.is_pinned;

      if (isPinned) {
        // Unpin message
        await axios.delete(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages/${messageId}/pin`,
          { withCredentials: true }
        );
        
        // Update local state
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === messageId
              ? { ...msg, is_pinned: false }
              : msg
          )
        );
        
        toast.success("Message unpinned");
      } else {
        // Pin message
        await axios.post(
          `${import.meta.env.VITE_BASE_URL}/api/direct-messages/messages/${messageId}/pin`,
          { 
            receiver_id: selectedConversation.other_user_id 
          },
          { withCredentials: true }
        );
        
        // Update local state
        setMessages((prev) =>
          prev.map((msg) =>
            msg.message_id === messageId
              ? { ...msg, is_pinned: true }
              : msg
          )
        );
        
        toast.success("Message pinned");
      }
    } catch (error) {
      console.error("Error pinning/unpinning message:", error);
      toast.error("Failed to pin/unpin message");
    } finally {
      setPinningMessageId(null);
    }
  };

  // Handle emoji selection
  const handleEmojiSelect = (emoji) => {
    setNewMessage((prev) => prev + emoji);
    setShowEmojiPicker(false);
    textareaRef.current?.focus();
  };

  // Handle delete conversation
  const handleDeleteConversation = async () => {
    if (!conversationToDelete) return;

    setIsDeleting(true);
    try {
      await axios.delete(
        `${import.meta.env.VITE_BASE_URL}/api/direct-messages/conversations/${
          conversationToDelete.other_user_id
        }`,
        { withCredentials: true }
      );

      // Remove from conversations list immediately (outer sidebar)
      setConversations((prev) =>
        prev.filter((conv) => conv.other_user_id !== conversationToDelete.other_user_id)
      );

      // If this was the selected conversation, clear it (inner sidebar)
      if (selectedConversation?.other_user_id === conversationToDelete.other_user_id) {
        setSelectedConversation(null);
        setMessages([]);
        setSearchParams({});
      }

      // Close modal and show success message
      setShowDeleteModal(false);
      setConversationToDelete(null);
      toast.success("Conversation deleted successfully");
    } catch (error) {
      console.error("Error deleting conversation:", error);
      toast.error("Failed to delete conversation");
    } finally {
      setIsDeleting(false);
    }
  };



  // Handle drag and drop for the entire chat area - like TeamChat
  const handleChatDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  };

  const handleChatDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    // Only hide drag overlay if we're leaving the main container
    if (!e.currentTarget.contains(e.relatedTarget)) {
      setDragOver(false);
    }
  };

  const handleChatDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(Array.from(e.dataTransfer.files));
    }
  };

  // Format timestamp with accurate timing and timezone handling
  const formatTime = (timestamp) => {
    if (!timestamp) return "";

    // Handle different timestamp formats and ensure proper parsing
    let date;
    try {
      if (typeof timestamp === "string") {
        // Handle ISO string formats, ensure UTC parsing if no timezone info
        if (
          timestamp.includes("T") &&
          !timestamp.includes("Z") &&
          !timestamp.includes("+") &&
          !timestamp.includes("-", 10)
        ) {
          // Assume UTC if no timezone specified in ISO format
          date = new Date(timestamp + "Z");
        } else {
          date = new Date(timestamp);
        }
      } else if (typeof timestamp === "number") {
        // Handle Unix timestamp (seconds or milliseconds)
        date =
          timestamp > 1000000000000
            ? new Date(timestamp)
            : new Date(timestamp * 1000);
      } else {
        date = new Date(timestamp);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn("Invalid timestamp:", timestamp);
        return "Invalid date";
      }
    } catch (error) {
      console.warn("Error parsing timestamp:", timestamp, error);
      return "Invalid date";
    }

    const now = new Date();
    const diff = now.getTime() - date.getTime();

    // Handle future dates (clock sync issues)
    if (diff < 0) {
      const futureDiff = Math.abs(diff);
      if (futureDiff < 30000) return "Just now"; // Within 30 seconds, assume clock sync issue
      return "Just now"; // Don't show future times
    }

    // Less than 30 seconds
    if (diff < 30000) return "Just now";

    // Less than 1 minute
    if (diff < 60000) return "Less than a minute ago";

    // Less than 1 hour
    if (diff < 3600000) {
      const minutes = Math.floor(diff / 60000);
      return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
    }

    // Same day
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    }

    // Yesterday
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday at ${date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })}`;
    }

    // Less than 7 days
    if (diff < 604800000) {
      const days = Math.floor(diff / 86400000);
      return `${days} day${days === 1 ? "" : "s"} ago`;
    }

    // More than 7 days
    const currentYear = now.getFullYear();
    const messageYear = date.getFullYear();

    if (currentYear === messageYear) {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    } else {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    }
  };



  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading conversations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-gray-50 relative overflow-hidden">
      {/* Conversations Sidebar */}
      <div
        className={`
          ${isMobile 
            ? (selectedConversation ? "hidden" : "flex") 
            : (sidebarVisible ? "flex" : "hidden")
          } 
          flex-col bg-white border-r border-gray-200 transition-all duration-300 ease-out
          ${isMobile 
            ? "w-full" 
            : sidebarVisible 
              ? "w-80 lg:w-96 xl:w-80" 
              : "w-0"
          }
          overflow-hidden shadow-lg
        `}
      >
        {/* Header */}
        <div className="p-3 sm:p-4 border-b border-gray-200">
          <div className="flex items-center justify-between mt-2 sm:mt-0 mb-4">
            <h1 className="text-lg sm:text-xl font-bold text-gray-900 pl-14 sm:pl-0">Messages</h1>
            <button
              onClick={() => setShowNewConversation(true)}
              className="p-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors touch-manipulation"
              title="New conversation"
            >
              <Plus size={16} className="sm:w-[18px] sm:h-[18px]" />
            </button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 sm:w-[18px] sm:h-[18px]"
            />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 sm:pl-10 pr-4 py-2.5 sm:py-2 bg-gray-100 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 touch-manipulation"
            />
          </div>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {filteredConversations.length === 0 ? (
            <div className="text-center py-6 sm:py-8 px-4">
              <MessageCircle size={32} className="mx-auto mb-3 sm:mb-4 text-gray-400 sm:w-10 sm:h-10" />
              <p className="text-gray-600 text-sm">
                {searchQuery
                  ? "No conversations found"
                  : "No conversations yet"}
              </p>
              {!searchQuery && (
                <button
                  onClick={() => setShowNewConversation(true)}
                  className="mt-2 text-purple-600 hover:text-purple-700 text-sm font-medium touch-manipulation"
                >
                  Start a conversation
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-1 p-1 sm:p-2">
              {filteredConversations.map((conversation) => (
                <div
                  key={conversation.other_user_id}
                  className={`conversation-item flex items-center p-2.5 sm:p-3 rounded-lg cursor-pointer group relative touch-manipulation ${
                    selectedConversation?.other_user_id ===
                    conversation.other_user_id
                      ? "bg-purple-100 border border-purple-200"
                      : "hover:bg-gray-100 active:bg-gray-200"
                  } ${
                    conversation.hasNewMessage ? "conversation-new-message" : ""
                  }`}
                  onClick={() => handleSelectConversation(conversation)}
                >
                  {/* Avatar */}
                  <div className="relative flex-shrink-0">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold overflow-hidden">
                      {conversation.other_user_photo ? (
                        <img
                          src={conversation.other_user_photo}
                          alt={conversation.other_user_name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-sm sm:text-base">
                          {conversation.other_user_name
                            ?.charAt(0)
                            ?.toUpperCase() || "U"}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 ml-2.5 sm:ml-3 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-semibold text-gray-900 truncate text-sm sm:text-base">
                        {conversation.other_user_name}
                      </h3>
                      <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                        {formatTime(conversation.last_message_time)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <p className="text-xs sm:text-sm text-gray-600 truncate flex-1 pr-2">
                        {conversation.last_message_content || "No messages yet"}
                      </p>

                      {conversation.unread_count > 0 && (
                        <div className="ml-2 flex items-center justify-center min-w-[18px] h-[18px] sm:min-w-[20px] sm:h-5 bg-purple-600 text-white text-xs font-bold rounded-full px-1">
                          {conversation.unread_count > 99 ? "99+" : conversation.unread_count}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Conversation Actions */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity hidden sm:block">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setConversationToDelete(conversation);
                        setShowDeleteModal(true);
                      }}
                      className="p-2 hover:bg-red-50 rounded-lg transition-colors touch-manipulation"
                      title="Delete conversation"
                    >
                      <Trash2
                        size={14}
                        className="text-gray-400 hover:text-red-600 sm:w-4 sm:h-4"
                      />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      {selectedConversation ? (
        <div
          className={`
            ${isMobile ? "w-full" : "flex-1"} 
            flex flex-col transition-all duration-300 ease-in-out relative
          `}
          onDragOver={handleChatDragOver}
          onDragLeave={handleChatDragLeave}
          onDrop={handleChatDrop}
        >

          {/* Chat Header */}
          <div className="bg-white border-b border-gray-200 p-4 sm:p-4 pl-17 sm:pl-0 flex items-center">
            {/* Sidebar Toggle Button */}
            <button
              onClick={() => setSidebarVisible(!sidebarVisible)}
              className="hidden md:flex mr-2 sm:mr-3 p-2 hover:bg-gray-100 rounded-lg transition-all touch-manipulation"
              title={
                sidebarVisible
                  ? "Hide conversations (Ctrl+B)"
                  : "Show conversations (Ctrl+B)"
              }
            >
              {sidebarVisible ? (
                <PanelLeftClose size={18} className="text-gray-600 sm:w-5 sm:h-5" />
              ) : (
                <PanelLeftOpen size={18} className="text-gray-600 sm:w-5 sm:h-5" />
              )}
            </button>

            <div className="flex items-center flex-1 min-w-0">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold overflow-hidden flex-shrink-0">
                {selectedConversation.other_user_photo ? (
                  <img
                    src={selectedConversation.other_user_photo}
                    alt={selectedConversation.other_user_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-sm sm:text-base">
                    {selectedConversation.other_user_name
                      ?.charAt(0)
                      ?.toUpperCase() || "U"}
                  </span>
                )}
              </div>
              <div className="ml-2 sm:ml-3 flex-1 min-w-0">
                <h2 className="font-semibold text-gray-900 text-base truncate">
                  {selectedConversation.other_user_name}
                </h2>
                <p className="text-sm text-gray-500 truncate">
                  {selectedConversation.other_user_email}
                </p>
              </div>
            </div>

            {/* Mobile Back Button - Moved to right side */}
            <button
              onClick={() => {
                setIsNavigatingBack(true);
                setSelectedConversation(null);
                setMessages([]);
                // Explicitly remove the user parameter from URL
                const newSearchParams = new URLSearchParams(searchParams);
                newSearchParams.delete('user');
                setSearchParams(newSearchParams);
                // Reset the navigation flag after a short delay
                setTimeout(() => setIsNavigatingBack(false), 100);
                // The useEffect will handle showing the sidebar on mobile
              }}
              className="md:hidden ml-2 sm:ml-3 p-2 hover:bg-gray-100 active:bg-gray-200 rounded-lg touch-manipulation"
              title="Back to conversations"
            >
              <ArrowLeft size={18} className="sm:w-5 sm:h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-2 sm:p-4 space-y-2 sm:space-y-3 bg-gray-50 messages-smooth-scroll">
            {messagesLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-t-2 border-purple-600"></div>
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center py-6 sm:py-8 px-4">
                <MessageCircle
                  size={32}
                  className="mx-auto mb-3 sm:mb-4 text-gray-400 sm:w-10 sm:h-10"
                />
                <p className="text-gray-600 text-sm sm:text-base">
                  Start a conversation with{" "}
                  {selectedConversation.other_user_name}
                </p>
              </div>
            ) : (
              messages.map((message, index) => {
                const showAvatar =
                  index === 0 ||
                  messages[index - 1].sender_id !== message.sender_id;
                const isOwnMessage = message.sender_id === user.user_id;

                return (
                  <div
                    key={message.message_id}
                    className={`group transition-all duration-200 hover:bg-gray-100/50 rounded-lg p-1 sm:p-2 -m-1 sm:-m-2 ${
                      showAvatar ? "mt-3 sm:mt-4" : "mt-0.5 sm:mt-1"
                    } ${
                      message.isNew
                        ? "animate-in slide-in-from-bottom-2 duration-300"
                        : ""
                    } ${message.isOptimistic ? "opacity-80" : ""} ${
                      message.isDeleting
                        ? "animate-out slide-out-to-right-2 duration-300"
                        : ""
                    } ${message.status === "failed" ? "opacity-60" : ""}`}
                  >
                    <div
                      className={`flex gap-1.5 sm:gap-2 ${
                        isOwnMessage ? "flex-row-reverse" : ""
                      }`}
                    >
                      {/* Avatar */}
                      {showAvatar ? (
                        <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold text-xs sm:text-sm overflow-hidden flex-shrink-0">
                          {isOwnMessage ? (
                            user.user_photo ? (
                              <img
                                src={user.user_photo}
                                alt={user.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <span className="text-xs sm:text-sm">
                                {user.name?.charAt(0)?.toUpperCase() || "U"}
                              </span>
                            )
                          ) : selectedConversation.other_user_photo ? (
                            <img
                              src={selectedConversation.other_user_photo}
                              alt={selectedConversation.other_user_name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="text-xs sm:text-sm">
                              {selectedConversation.other_user_name
                                ?.charAt(0)
                                ?.toUpperCase() || "U"}
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="w-6 sm:w-8 flex-shrink-0"></div>
                      )}

                      <div
                        className={`flex-1 min-w-0 ${
                          isOwnMessage ? "text-right" : ""
                        }`}
                      >
                        {/* Header with actions */}
                        {(showAvatar || !message.isDeleted) && (
                          <div
                            className={`flex items-center gap-1.5 sm:gap-2 mb-1 ${
                              isOwnMessage ? "flex-row-reverse" : ""
                            }`}
                          >
                            {showAvatar && (
                              <span className="text-xs text-gray-500">
                                {formatTime(message.created_at)}
                              </span>
                            )}

                            {/* Message actions - Hidden on mobile, shown on hover on desktop */}
                            {!message.isDeleted && (
                              <div className="opacity-0 group-hover:opacity-100 transition-all duration-200 hidden sm:block">
                                <div className="bg-white border border-gray-200 rounded-lg shadow-lg flex items-center gap-1 p-1">
                                <button
                                  onClick={() =>
                                    handleReaction(message.message_id, "👍")
                                  }
                                  className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                                  title="Like"
                                >
                                  <ThumbsUp size={14} />
                                </button>
                                <button
                                  onClick={() =>
                                    handleReaction(message.message_id, "❤️")
                                  }
                                  className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-red-600 transition-colors cursor-pointer"
                                  title="Love"
                                >
                                  <Heart size={14} />
                                </button>
                                <button
                                  onClick={() => handleReply(message)}
                                  className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                                  title="Reply"
                                >
                                  <Reply size={14} />
                                </button>
                                <button
                                  onClick={() => handlePinMessage(message.message_id)}
                                  disabled={pinningMessageId === message.message_id}
                                  className={`p-2 hover:bg-purple-50 rounded-md transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                                    message.is_pinned 
                                      ? 'text-purple-600 hover:text-purple-700' 
                                      : 'text-gray-500 hover:text-purple-600'
                                  }`}
                                  title={message.is_pinned ? "Unpin message" : "Pin message"}
                                >
                                  {pinningMessageId === message.message_id ? (
                                    <Loader2 size={14} className="animate-spin" />
                                  ) : (
                                    <Pin size={14} className={message.is_pinned ? 'fill-current' : ''} />
                                  )}
                                </button>
                                {isOwnMessage && (
                                  <>
                                    <div className="w-px h-6 bg-gray-200 mx-1"></div>
                                    <button
                                      onClick={() =>
                                        handleEditMessage(message)
                                      }
                                      className="p-2 hover:bg-blue-50 rounded-md text-gray-500 hover:text-blue-600 transition-colors cursor-pointer"
                                      title="Edit"
                                    >
                                      <Edit2 size={14} />
                                    </button>
                                    <button
                                      onClick={() =>
                                        handleDeleteMessage(
                                          message.message_id
                                        )
                                      }
                                      className="p-2 hover:bg-red-50 rounded-md text-gray-500 hover:text-red-600 transition-colors cursor-pointer"
                                      title="Delete"
                                    >
                                      <Trash2 size={14} />
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          )}
                          </div>
                        )}

                        {/* Reply indicator */}
                        {message.reply_to && (
                          <div
                            className={`bg-gray-100 border-l-4 border-gray-300 pl-2 sm:pl-3 py-1.5 sm:py-2 mb-1.5 sm:mb-2 rounded-r ${
                              isOwnMessage ? "bg-blue-50 border-blue-300" : ""
                            }`}
                          >
                            <div className="text-xs text-gray-600 mb-0.5 sm:mb-1">
                              Replying to {message.reply_to_sender_name}
                            </div>
                            <div className="text-xs sm:text-sm text-gray-800 truncate">
                              {message.reply_to_content}
                            </div>
                          </div>
                        )}

                        {/* Message content */}
                        <div
                          className={`flex flex-col ${
                            isOwnMessage ? "items-end" : "items-start"
                          }`}
                        >
                          {message.isDeleted ? (
                            <div
                              className={`text-sm italic p-3 rounded-2xl ${
                                isOwnMessage
                                  ? "bg-gray-200 text-gray-500"
                                  : "bg-gray-100 text-gray-500"
                              }`}
                            >
                              {message.content}
                            </div>
                          ) : message.file_url ? (
                            <div
                              className={`rounded-2xl p-2.5 sm:p-4 inline-block max-w-[280px] sm:max-w-xs md:max-w-md shadow-sm relative transition-all duration-200 ${
                                isOwnMessage
                                  ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white ml-auto rounded-br-md"
                                  : "bg-white border border-gray-200 rounded-bl-md"
                              } ${
                                message.isUploading ||
                                message.status === "uploading"
                                  ? "opacity-75 animate-pulse"
                                  : ""
                              } ${
                                message.status === "failed"
                                  ? "opacity-60 border-red-200"
                                  : ""
                              }`}
                            >
                              {/* Pinned indicator badge for files */}
                              {message.is_pinned && (
                                <div className={`absolute -top-2 -left-2 ${
                                  isOwnMessage ? '-right-2 -left-auto' : ''
                                }`}>
                                  <div className="bg-purple-600 text-white rounded-full p-1 shadow-lg">
                                    <Pin size={10} className="fill-current" />
                                  </div>
                                </div>
                              )}

                              {/* Upload progress overlay */}
                              {message.isUploading && (
                                <div className="absolute inset-0 bg-black bg-opacity-20 rounded-2xl flex items-center justify-center">
                                  <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-white"></div>
                                </div>
                              )}

                              {message.file_type?.startsWith("image/") ? (
                                <div className="relative">
                                  <img
                                    src={message.file_url}
                                    alt={message.file_name}
                                    className={`max-w-full h-auto rounded cursor-pointer transition-opacity ${
                                      message.isUploading ? "opacity-50" : ""
                                    }`}
                                    onClick={() => {
                                      if (!message.isUploading) {
                                        window.open(message.file_url, "_blank");
                                      }
                                    }}
                                  />
                                  {message.file_name && (
                                    <div className="mt-2 text-xs opacity-75">
                                      {message.file_name}
                                    </div>
                                  )}
                                </div>
                              ) : message.file_type?.startsWith("audio/") ? (
                                <div className="space-y-2 min-w-[250px]">
                                  <audio
                                    src={message.file_url}
                                    controls
                                    className="w-full"
                                    preload="metadata"
                                  >
                                    Your browser does not support the audio tag.
                                  </audio>
                                  <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                      <span className="text-lg">🎵</span>
                                      <div className="flex-1 min-w-0">
                                        <div
                                          className={`text-sm font-medium truncate ${
                                            isOwnMessage
                                              ? "text-white"
                                              : "text-gray-900"
                                          }`}
                                        >
                                          {message.file_name || "Voice message"}
                                        </div>
                                        {message.file_size && (
                                          <div
                                            className={`text-xs ${
                                              isOwnMessage
                                                ? "text-blue-100"
                                                : "text-gray-500"
                                            }`}
                                          >
                                            {(message.file_size / 1024).toFixed(1)} KB
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                    <div className="flex items-center gap-1">
                                      {!message.isUploading && (
                                        <button
                                          onClick={() =>
                                            window.open(message.file_url, "_blank")
                                          }
                                          className={`p-1 rounded cursor-pointer ${
                                            isOwnMessage
                                              ? "hover:bg-blue-600"
                                              : "hover:bg-gray-200"
                                          }`}
                                          title="Download audio"
                                        >
                                          <Download
                                            size={16}
                                            className={
                                              isOwnMessage
                                                ? "text-white"
                                                : "text-gray-600"
                                            }
                                          />
                                        </button>
                                      )}
                                      {isOwnMessage && !message.isUploading && (
                                        <button
                                          onClick={() =>
                                            handleDeleteMessage(message.message_id)
                                          }
                                          className="p-1 rounded cursor-pointer hover:bg-red-600 text-white"
                                          title="Delete audio message"
                                        >
                                          <Trash2 size={16} />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 sm:gap-3">
                                  <File
                                    size={20}
                                    className={`${
                                      isOwnMessage
                                        ? "text-white"
                                        : "text-gray-600"
                                    } sm:w-6 sm:h-6`}
                                  />
                                  <div className="flex-1 min-w-0">
                                    <div
                                      className={`text-xs sm:text-sm font-medium truncate ${
                                        isOwnMessage
                                          ? "text-white"
                                          : "text-gray-900"
                                      }`}
                                    >
                                      {message.file_name}
                                    </div>
                                    {message.isUploading && (
                                      <div className="text-xs opacity-75 mt-0.5 sm:mt-1">
                                        Uploading...
                                      </div>
                                    )}
                                  </div>
                                  {!message.isUploading && (
                                    <button
                                      onClick={() =>
                                        window.open(message.file_url, "_blank")
                                      }
                                      className={`p-1.5 sm:p-2 rounded touch-manipulation ${
                                        isOwnMessage
                                          ? "hover:bg-blue-600 active:bg-blue-700"
                                          : "hover:bg-gray-200 active:bg-gray-300"
                                      }`}
                                      title="Download file"
                                    >
                                      <Download
                                        size={14}
                                        className={`${
                                          isOwnMessage
                                            ? "text-white"
                                            : "text-gray-600"
                                        } sm:w-4 sm:h-4`}
                                      />
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div
                              className={`text-sm leading-relaxed break-words p-2.5 sm:p-4 rounded-2xl shadow-sm inline-block max-w-[280px] sm:max-w-xs md:max-w-md transition-all duration-200 relative ${
                                message.isDeleted
                                  ? "bg-gray-100 text-gray-500 italic"
                                  : isOwnMessage
                                  ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white ml-auto rounded-br-md"
                                  : "bg-white text-gray-800 rounded-bl-md border border-gray-200"
                              } ${
                                message.isOptimistic ||
                                message.status === "sending"
                                  ? "opacity-80"
                                  : ""
                              } ${
                                message.status === "failed"
                                  ? "opacity-60 border-red-200 bg-red-50"
                                  : ""
                              }`}
                            >
                              {message.content}

                              {/* Pinned indicator badge */}
                              {message.is_pinned && (
                                <div className={`absolute -top-2 -left-2 ${
                                  isOwnMessage ? '-right-2 -left-auto' : ''
                                }`}>
                                  <div className="bg-purple-600 text-white rounded-full p-1 shadow-lg">
                                    <Pin size={10} className="fill-current" />
                                  </div>
                                </div>
                              )}

                              {/* Status indicators for own messages */}
                              {isOwnMessage && !message.isDeleted && (
                                <div className="absolute -bottom-1 -right-1">
                                  {message.status === "sending" ||
                                  message.isOptimistic ? (
                                    <div className="w-3 h-3 bg-gray-300 rounded-full animate-pulse"></div>
                                  ) : message.status === "failed" ? (
                                    <div
                                      className="w-3 h-3 bg-red-400 rounded-full"
                                      title="Failed to send"
                                    ></div>
                                  ) : (
                                    <CheckCheck
                                      size={14}
                                      className="text-blue-200"
                                    />
                                  )}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Reactions */}
                          {!message.isDeleted && (
                            <div className="mt-1">
                              <MessageReactions
                                reactions={message.reactions || []}
                                onReactionClick={(emoji) =>
                                  handleReaction(message.message_id, emoji)
                                }
                                currentUserId={user.user_id}
                                isOwnMessage={isOwnMessage}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Typing indicator */}
          {typingUsers.length > 0 && (
            <div className="px-2 sm:px-4 pb-1 sm:pb-2 typing-indicator">
              <TypingIndicator users={typingUsers} />
            </div>
          )}

          {/* Reply indicator */}
          {replyingTo && (
            <div className="bg-blue-50 border-t border-blue-200 p-2 sm:p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
                  <Reply size={14} className="text-blue-600 flex-shrink-0 sm:w-4 sm:h-4" />
                  <div className="min-w-0 flex-1">
                    <span className="text-xs sm:text-sm font-semibold text-blue-800 block">
                      Replying to {replyingTo.sender_name}
                    </span>
                    <div className="text-xs sm:text-sm text-gray-700 truncate">
                      {replyingTo.content}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setReplyingTo(null)}
                  className="p-1.5 sm:p-2 hover:bg-blue-100 active:bg-blue-200 rounded-full touch-manipulation flex-shrink-0"
                >
                  <X size={14} className="text-blue-600 sm:w-4 sm:h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Edit indicator */}
          {editingMessage && (
            <div className="bg-amber-50 border-t border-amber-200 p-2 sm:p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 sm:gap-3">
                  <Edit2 size={14} className="text-amber-600 sm:w-4 sm:h-4" />
                  <span className="text-xs sm:text-sm font-semibold text-amber-800">
                    Editing message
                  </span>
                </div>
                <button
                  onClick={() => {
                    setEditingMessage(null);
                    setNewMessage("");
                  }}
                  className="p-1.5 sm:p-2 hover:bg-amber-100 active:bg-amber-200 rounded-full touch-manipulation"
                >
                  <X size={14} className="text-amber-600 sm:w-4 sm:h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Message Input */}
          <div className="border-t border-gray-200 bg-white p-2 sm:p-4">
            <form onSubmit={sendMessage} className="relative">
              <div className="bg-white border-2 border-gray-200 rounded-2xl focus-within:border-purple-500 focus-within:ring-2 sm:focus-within:ring-4 focus-within:ring-purple-100 transition-all duration-200">
                <textarea
                  ref={textareaRef}
                  value={newMessage}
                  onChange={handleInputChange}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      const syntheticEvent = {
                        preventDefault: () => {},
                        target: e.target,
                        currentTarget: e.currentTarget,
                      };
                      sendMessage(syntheticEvent);
                    }
                  }}
                  placeholder={`Message ${selectedConversation.other_user_name}...`}
                  className="w-full bg-transparent text-gray-900 placeholder-gray-400 px-3 sm:px-6 py-3 sm:py-4 pr-16 sm:pr-24 resize-none outline-none max-h-[100px] sm:max-h-[120px] leading-relaxed text-sm sm:text-base"
                  rows="1"
                  disabled={sending}
                />

                <div className="flex items-center justify-between px-2 sm:px-4 pb-2 sm:pb-4">
                  <div className="flex items-center gap-1.5 sm:gap-3">

                    <button
                      type="button"
                      onClick={() => setShowVoiceRecorder(true)}
                      className="cursor-pointer p-1.5 sm:p-2 hover:bg-blue-100 active:bg-blue-200 rounded-xl text-gray-600 hover:text-blue-600 transition-all touch-manipulation"
                      title="Record voice message"
                    >
                      <Mic size={16} className="sm:w-[18px] sm:h-[18px]" />
                    </button>

                    <div className="relative" ref={emojiPickerRef}>
                      <button
                        type="button"
                        onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                        className="cursor-pointer p-1.5 sm:p-2 hover:bg-yellow-100 active:bg-yellow-200 rounded-xl text-gray-600 hover:text-yellow-600 transition-colors touch-manipulation"
                        title="Add emoji"
                      >
                        <Smile size={16} className="sm:w-[18px] sm:h-[18px]" />
                      </button>
                      {showEmojiPicker && (
                        <div className="absolute bottom-full left-0 mb-2 z-50">
                          <EmojiPicker
                            onEmojiSelect={handleEmojiSelect}
                          />
                        </div>
                      )}
                    </div>

                    <div className="relative">
                      <button
                        type="button"
                        onClick={() => setShowFileUpload(true)}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          fileInputRef.current?.click();
                        }}
                        className="cursor-pointer p-1.5 sm:p-2 hover:bg-purple-100 active:bg-purple-200 rounded-xl text-gray-600 hover:text-purple-600 transition-colors touch-manipulation"
                        title="Attach files"
                      >
                        <Paperclip size={16} className="sm:w-[18px] sm:h-[18px]" />
                      </button>

                      {/* Quick file input for single file uploads */}
                      <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files?.length) {
                            handleFileUpload(Array.from(e.target.files));
                            e.target.value = ""; // Reset input
                          }
                        }}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={!newMessage.trim() || sending}
                    onClick={(e) => {
                      e.preventDefault();
                      sendMessage(e);
                    }}
                    className={`flex items-center gap-2 sm:gap-3 px-3 sm:px-6 py-2 sm:py-3 rounded-xl font-semibold text-xs sm:text-sm transition-all duration-200 touch-manipulation ${
                      newMessage.trim() && !sending
                        ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 active:from-purple-800 active:to-blue-800 text-white shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
                        : "bg-gray-200 text-gray-400 cursor-not-allowed"
                    }`}
                  >
                    {sending ? (
                      <div className="animate-spin rounded-full h-3 w-3 sm:h-4 sm:w-4 border-t-2 border-white"></div>
                    ) : (
                      <Send size={12} className="sm:w-[14px] sm:h-[14px]" />
                    )}
                    <span className="hidden sm:inline">
                      {editingMessage ? "Update" : "Send"}
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      ) : !isMobile ? (
        <div className="flex-1 flex flex-col bg-gray-50 transition-all duration-300 ease-in-out">
          {/* Empty State Header with Sidebar Toggle */}
          <div className="bg-white border-b border-gray-200 p-3 sm:p-4 flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-semibold text-gray-900">Messages</h2>
            <button
              onClick={() => setSidebarVisible(!sidebarVisible)}
              className="p-2 hover:bg-gray-100 active:bg-gray-200 rounded-lg transition-all touch-manipulation"
              title={
                sidebarVisible
                  ? "Hide conversations (Ctrl+B)"
                  : "Show conversations (Ctrl+B)"
              }
            >
              {sidebarVisible ? (
                <PanelLeftClose size={18} className="text-gray-600 sm:w-5 sm:h-5" />
              ) : (
                <PanelLeftOpen size={18} className="text-gray-600 sm:w-5 sm:h-5" />
              )}
            </button>
          </div>

          {/* Empty State Content */}
          <div className="flex-1 flex items-center justify-center p-4">
            <div className="text-center max-w-sm">
              <MessageCircle size={48} className="mx-auto mb-3 sm:mb-4 text-gray-400 sm:w-16 sm:h-16" />
              <h2 className="text-lg sm:text-xl font-semibold text-gray-700 mb-2">
                {sidebarVisible
                  ? "Select a conversation"
                  : "No conversation selected"}
              </h2>
              <p className="text-sm sm:text-base text-gray-500 mb-4">
                {sidebarVisible
                  ? "Choose a conversation from the sidebar to start messaging"
                  : "Open the sidebar to see your conversations"}
              </p>
              {!sidebarVisible && (
                <button
                  onClick={() => setSidebarVisible(true)}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 active:bg-purple-800 transition-colors touch-manipulation"
                >
                  Show Conversations
                </button>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {/* New Conversation Modal */}
      {showNewConversation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-3 sm:p-4 transition-all duration-300">
          <div className="relative w-full max-w-sm sm:max-w-md glass-dark rounded-2xl sm:rounded-3xl overflow-hidden animate-fadeIn hover:scale-[1.01] transition-transform mx-auto">
            <div className="absolute inset-0 cosmic-bg"></div>
            <div className="relative p-4 sm:p-6">
              {/* Close Button */}
              <button
                onClick={() => {
                  setShowNewConversation(false);
                  setMemberSearchQuery("");
                }}
                className="absolute top-3 right-3 sm:top-4 sm:right-4 text-gray-400 hover:text-white transition-all cursor-pointer active:scale-95 p-1.5 sm:p-2 rounded-full hover:bg-gray-800/80 hover:rotate-90 transform duration-300"
              >
                <X size={18} className="sm:w-5 sm:h-5" />
              </button>

              {/* Header */}
              <div className="text-center mb-4 sm:mb-6">
                <div className="w-12 h-12 sm:w-16 sm:h-16 glass-button-enhanced rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <MessageCircle size={20} className="text-purple-400 sm:w-6 sm:h-6" />
                </div>
                <h2 className="text-lg sm:text-xl font-bold mb-2 text-white">
                  New Conversation
                </h2>
                <p className="text-gray-300 text-sm">
                  Start a conversation with a team member
                </p>
              </div>

              {/* Search members */}
              <div className="relative mb-4">
                <Search
                  size={16}
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                />
                <input
                  type="text"
                  placeholder="Search members..."
                  value={memberSearchQuery}
                  onChange={(e) => setMemberSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 sm:py-3 rounded-xl glass-effect text-white text-sm focus:ring-2 focus:ring-violet-500 focus:border-violet-500/50 focus:outline-none placeholder-gray-400 transition-all duration-200"
                />
              </div>

              {/* Members list */}
              <div className="max-h-64 overflow-y-auto space-y-2">
                {organizationMembers
                  .filter(
                    (member) =>
                      member.name
                        .toLowerCase()
                        .includes(memberSearchQuery.toLowerCase()) ||
                      member.email
                        .toLowerCase()
                        .includes(memberSearchQuery.toLowerCase())
                  )
                  .map((member) => (
                    <div
                      key={member.user_id}
                      className="flex items-center p-3 hover:bg-gray-800/50 rounded-xl cursor-pointer transition-all duration-200 glass"
                      onClick={() => handleStartNewConversation(member)}
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center text-white font-semibold overflow-hidden">
                        {member.user_photo ? (
                          <img
                            src={member.user_photo}
                            alt={member.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          member.name.charAt(0).toUpperCase()
                        )}
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium text-white text-sm">
                          {member.name}
                        </h3>
                        <p className="text-xs text-gray-400">{member.email}</p>
                      </div>
                    </div>
                  ))}
                {organizationMembers.filter(
                  (member) =>
                    member.name
                      .toLowerCase()
                      .includes(memberSearchQuery.toLowerCase()) ||
                    member.email
                      .toLowerCase()
                      .includes(memberSearchQuery.toLowerCase())
                ).length === 0 && (
                  <div className="text-center py-8">
                    <MessageCircle size={32} className="mx-auto mb-3 text-gray-500" />
                    <p className="text-gray-400 text-sm">
                      {memberSearchQuery ? "No members found" : "No members available"}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Drag and Drop Overlay - like TeamChat */}
      {dragOver && selectedConversation && (
        <div className="absolute inset-0 bg-purple-500/10 backdrop-blur-sm border-2 border-dashed border-purple-400 rounded-lg flex items-center justify-center z-40">
          <div className="text-center p-8">
            <div className="text-6xl mb-4">📁</div>
            <h3 className="text-xl font-semibold text-purple-700 mb-2">
              Drop files here
            </h3>
            <p className="text-purple-600">
              Release to upload files to {selectedConversation.other_user_name}
            </p>
          </div>
        </div>
      )}

      {/* File Upload Modal */}
      {showFileUpload && (
        <FileUpload
          onUpload={handleFileUpload}
          onClose={() => setShowFileUpload(false)}
          maxFiles={5}
          maxSize={10 * 1024 * 1024}
        />
      )}

      {/* Voice Recorder Modal */}
      {showVoiceRecorder && (
        <VoiceRecorder
          onSend={handleVoiceUpload}
          onClose={() => setShowVoiceRecorder(false)}
        />
      )}

      {/* Delete Conversation Modal */}
      <ConfirmationModal
        isOpen={showDeleteModal}
        onClose={() => {
          setShowDeleteModal(false);
          setConversationToDelete(null);
        }}
        onConfirm={handleDeleteConversation}
        title="Delete Conversation"
        message={
          conversationToDelete
            ? `Are you sure you want to delete your entire conversation with ${conversationToDelete.other_user_name}? This will permanently remove all messages, files, and reactions from this conversation for both users.`
            : ""
        }
        confirmText="Delete Conversation"
        cancelText="Cancel"
        type="danger"
        loading={isDeleting}
      />
    </div>
  );
};

export default Messages;
